'use client';

import { useEffect, useMemo, useState } from 'react';
import {
  Activity,
  AlertTriangle,
  Atom,
  CheckCircle2,
  Database,
  Download,
  ExternalLink,
  FileUp,
  FlaskConical,
  Info,
  LoaderCircle,
  LockKeyhole,
  Play,
  ScanLine,
  Search,
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { CifViewer } from '@/components/cif-viewer';
import { CrystallinityPanel } from '@/components/crystallinity-panel';
import { MultiPhasePanel } from '@/components/multi-phase-panel';
import { XrdPlot } from '@/components/xrd-plot';
import {
  analyzePattern,
  convertWavelength,
  materializePattern,
  normalizedForPlot,
  parseXrdText,
  type MatchResult,
  type Point,
  type ReferenceLibrary,
} from '@/lib/xrd';

const kindLabel: Record<string, string> = {
  measured_verified_synthesis: 'IZA 实测 · Verified Syntheses',
  measured_type_material: 'IZA 实测 · 标准材料',
  measured: 'IZA 实测',
  simulated_DIFFaX_intergrowth: 'IZA DIFFaX 交生模拟',
  calculated_IZA: 'IZA 计算谱',
  simulated: 'CIF 模拟',
};

const escapeHtml = (value: string) =>
  value.replace(
    /[&<>"']/g,
    (char) =>
      ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[
        char
      ] || char,
  );
const assetUrl = (path: string) => new URL(path, document.baseURI).toString();
const safeFilePart = (value: string) =>
  value.replace(/[^\p{L}\p{N}._-]+/gu, '_').replace(/^_+|_+$/g, '') ||
  'reference';

export default function Home() {
  const [library, setLibrary] = useState<ReferenceLibrary | null>(null);
  const [rawSample, setRawSample] = useState<Point[]>([]);
  const [analysisSample, setAnalysisSample] = useState<Point[]>([]);
  const [sampleName, setSampleName] = useState('');
  const [sampleState, setSampleState] = useState('unknown');
  const [fileName, setFileName] = useState('');
  const [wavelengthMode, setWavelengthMode] = useState('1.5406');
  const [customWavelength, setCustomWavelength] = useState('1.5406');
  const [results, setResults] = useState<MatchResult[]>([]);
  const [selectedIndex, setSelectedIndex] = useState(0);
  const [selectedCif, setSelectedCif] = useState('');
  const [status, setStatus] = useState<
    'idle' | 'ready' | 'analyzing' | 'done' | 'error'
  >('idle');
  const [error, setError] = useState('');
  const [progress, setProgress] = useState(0);
  const [libraryQuery, setLibraryQuery] = useState('');

  useEffect(() => {
    fetch(assetUrl('library/reference-index.json'))
      .then(async (response) => {
        if (!response.ok) throw new Error('参考库加载失败');
        return (await response.json()) as ReferenceLibrary;
      })
      .then((data) => setLibrary(data))
      .catch((reason) => {
        setError(String(reason));
        setStatus('error');
      });
  }, []);

  const selected = results[selectedIndex];
  const structureOptions =
    library && selected ? library.structures[selected.framework] || [] : [];
  const activeCif = structureOptions.some(
    (option) => option.path === selectedCif,
  )
    ? selectedCif
    : structureOptions[0]?.path || '';

  const samplePlot = useMemo(
    () => normalizedForPlot(analysisSample),
    [analysisSample],
  );
  const referencePlot = useMemo(
    () =>
      selected
        ? normalizedForPlot(materializePattern(selected.reference.pattern))
        : [],
    [selected],
  );
  const librarySearchResults = useMemo(() => {
    if (!library) return [];
    const query = libraryQuery.trim().toLocaleLowerCase();
    const ranked = library.references.filter((reference) => {
      if (!query) return true;
      return [
        reference.framework,
        reference.material,
        kindLabel[reference.kind || ''] || reference.kind,
        reference.state,
      ]
        .filter(Boolean)
        .join(' ')
        .toLocaleLowerCase()
        .includes(query);
    });
    return ranked
      .sort(
        (left, right) =>
          left.framework.localeCompare(right.framework) ||
          (left.material || '').localeCompare(right.material || ''),
      )
      .slice(0, 80);
  }, [library, libraryQuery]);

  function downloadReferenceTxt(
    reference: ReferenceLibrary['references'][number],
  ) {
    const points = materializePattern(reference.pattern);
    const header = [
      '# Zeolite XRD Lab reference pattern',
      `# framework: ${reference.framework}`,
      `# material: ${reference.material || reference.framework}`,
      `# kind: ${reference.kind || 'not specified'} (${kindLabel[reference.kind || ''] || '未分类'})`,
      `# comparison_wavelength_A: ${reference.wavelength_angstrom.toFixed(5)}`,
      reference.source_wavelength_angstrom
        ? `# source_wavelength_A: ${reference.source_wavelength_angstrom.toFixed(5)}`
        : '',
      reference.source ? `# source: ${reference.source}` : '',
      reference.download_date ? `# cached_on: ${reference.download_date}` : '',
      '# columns: 2theta_deg intensity_normalized',
      '# intensity: maximum normalized to 100; suitable for plotting and phase screening',
      '# note: calculated/simulated and measured patterns are distinct; intensity is not phase fraction',
    ].filter(Boolean);
    const rows = points.map(
      (point) => `${point.x.toFixed(4)}\t${point.y.toFixed(6)}`,
    );
    const url = URL.createObjectURL(
      new Blob([[...header, ...rows].join('\r\n') + '\r\n'], {
        type: 'text/plain;charset=utf-8',
      }),
    );
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = `${safeFilePart(reference.framework)}_${safeFilePart(reference.material || reference.framework)}_CuKa1.txt`;
    anchor.click();
    window.setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  async function analyze(points = rawSample, sourceWavelength?: number) {
    if (!library) {
      setError('参考库仍在加载，请稍候。');
      return [] as MatchResult[];
    }
    if (!points.length) {
      setError('请先选择 XRD 数据文件，或载入示例。');
      setStatus('error');
      return [];
    }
    const wavelength =
      sourceWavelength ??
      Number(wavelengthMode === 'custom' ? customWavelength : wavelengthMode);
    if (!Number.isFinite(wavelength) || wavelength <= 0) {
      setError('请输入有效的实验波长。');
      setStatus('error');
      return [];
    }
    setStatus('analyzing');
    setError('');
    setProgress(18);
    await new Promise((resolve) => setTimeout(resolve, 40));
    try {
      const converted = convertWavelength(
        points,
        wavelength,
        library.comparison_wavelength_angstrom,
      );
      setAnalysisSample(converted);
      setProgress(56);
      await new Promise((resolve) => setTimeout(resolve, 30));
      const ranked = analyzePattern(converted, library);
      setResults(ranked);
      setSelectedIndex(0);
      setProgress(100);
      setStatus('done');
      return ranked;
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : String(reason));
      setStatus('error');
      setProgress(0);
      return [];
    }
  }

  async function loadDemo() {
    try {
      const response = await fetch(assetUrl('library/demo-im5.xy'));
      const points = parseXrdText(await response.text());
      setRawSample(points);
      setSampleName('IM-5 示例');
      setFileName('demo-im5.xy');
      setWavelengthMode('1.5406');
      setStatus('ready');
      return await analyze(points, 1.5406);
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : String(reason));
      setStatus('error');
      return [];
    }
  }

  useEffect(() => {
    if (!library) return;
    const context = (
      document as Document & {
        modelContext?: {
          registerTool: (
            tool: unknown,
            options?: { signal?: AbortSignal },
          ) => void | Promise<void>;
        };
      }
    ).modelContext;
    if (!context?.registerTool) return;
    const lifecycle = new AbortController();
    void Promise.resolve(
      context.registerTool(
        {
          name: 'analyze_demo_xrd',
          title: '分析 IM-5 示例谱',
          description:
            '载入网站内置的 IM-5 粉末 XRD 示例，运行完整结构匹配并更新页面结果。',
          inputSchema: {
            type: 'object',
            properties: {},
            additionalProperties: false,
          },
          annotations: { readOnlyHint: false, untrustedContentHint: false },
          execute: async () => {
            const response = await fetch(assetUrl('library/demo-im5.xy'));
            const points = parseXrdText(await response.text());
            const converted = convertWavelength(
              points,
              1.5406,
              library.comparison_wavelength_angstrom,
            );
            const ranked = analyzePattern(converted, library);
            setRawSample(points);
            setAnalysisSample(converted);
            setSampleName('IM-5 示例');
            setFileName('demo-im5.xy');
            setWavelengthMode('1.5406');
            setResults(ranked);
            setSelectedIndex(0);
            setStatus('done');
            setProgress(100);
            return {
              top_framework: ranked[0]?.framework,
              score: Number(ranked[0]?.score.toFixed(1)),
              candidates: ranked.slice(0, 3).map((item) => item.framework),
            };
          },
        },
        { signal: lifecycle.signal },
      ),
    ).catch(() => undefined);
    return () => lifecycle.abort();
  }, [library]);

  async function handleFile(file?: File) {
    if (!file) return;
    try {
      const points = parseXrdText(await file.text());
      setRawSample(points);
      setAnalysisSample([]);
      setResults([]);
      setFileName(file.name);
      setSampleName((current) => current || file.name.replace(/\.[^.]+$/, ''));
      setStatus('ready');
      setError('');
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : String(reason));
      setStatus('error');
    }
  }

  function exportReport() {
    if (!results.length) return;
    const title = escapeHtml(sampleName || fileName || 'XRD 样品');
    const rows = results
      .slice(0, 8)
      .map(
        (item, index) =>
          `<tr><td>${index + 1}</td><td><b>${escapeHtml(item.framework)}</b></td><td>${escapeHtml(item.material)}</td><td>${item.score.toFixed(1)}</td><td>${(item.expectedCoverage * 100).toFixed(0)}%</td><td>${(item.sampleExplained * 100).toFixed(0)}%</td><td>${item.shift >= 0 ? '+' : ''}${item.shift.toFixed(2)}°</td><td>${item.confidence}</td></tr>`,
      )
      .join('');
    const html = `<!doctype html><meta charset="utf-8"><title>${title} · XRD结构分析</title><style>body{font-family:Arial,"Microsoft YaHei",sans-serif;margin:42px;color:#17324d}h1{margin-bottom:4px}small{color:#60758a}table{width:100%;border-collapse:collapse;margin:28px 0}th,td{border-bottom:1px solid #d8e2eb;padding:10px;text-align:left}th{background:#edf5fb}.note{background:#fff6dc;border-left:4px solid #f4b942;padding:14px;line-height:1.65}</style><h1>${title}</h1><small>Zeolite XRD Lab · ${new Date().toLocaleString('zh-CN')} · 比对波长 1.54060 Å</small><h2>候选结构排序</h2><table><thead><tr><th>#</th><th>框架</th><th>参考材料</th><th>评分</th><th>预期峰覆盖</th><th>样品峰解释</th><th>校正</th><th>证据等级</th></tr></thead><tbody>${rows}</tbody></table><div class="note"><b>解释边界：</b>评分用于候选排序，不是概率、相含量或自动确认。XRD 不能单独证明 Si/Al、杂原子进入骨架、酸性或孔道性能。相对结晶度必须使用组成和处理历史匹配、且在同等条件下测量的实体标准样。</div>`;
    const url = URL.createObjectURL(
      new Blob([html], { type: 'text/html;charset=utf-8' }),
    );
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = `${sampleName || 'xrd'}_结构分析报告.html`;
    anchor.click();
    URL.revokeObjectURL(url);
  }

  const rangeText = rawSample.length
    ? `${rawSample[0].x.toFixed(2)}–${rawSample[rawSample.length - 1].x.toFixed(2)}°`
    : '—';

  return (
    <main className="min-h-screen bg-background text-foreground">
      <header className="border-b border-border/80 bg-card/90 backdrop-blur">
        <div className="mx-auto flex h-16 max-w-[1540px] items-center justify-between px-4 sm:px-7">
          <div className="flex items-center gap-3">
            <div className="grid size-9 place-items-center rounded-lg bg-primary text-primary-foreground shadow-[0_8px_24px_rgba(20,91,187,.22)]">
              <Activity className="size-5" />
            </div>
            <div>
              <div className="font-semibold tracking-[-.02em]">
                Zeolite XRD Lab
              </div>
              <div className="text-xs text-muted-foreground">
                分子筛结构识别工作台
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Dialog>
              <DialogTrigger
                render={
                  <Button size="sm" variant="outline" disabled={!library} />
                }
              >
                <Search /> 标准图谱库
              </DialogTrigger>
              <DialogContent className="max-h-[85vh] max-w-[calc(100%-2rem)] overflow-hidden p-0 sm:max-w-4xl">
                <DialogHeader className="border-b p-5 pr-12">
                  <DialogTitle className="flex items-center gap-2">
                    <Database className="size-4 text-primary" />{' '}
                    标准图谱搜索与下载
                  </DialogTitle>
                  <DialogDescription>
                    检索本地缓存的 IZA/COD 实测与模拟参考谱；TXT 为两列
                    2θ–归一化强度数据。
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-3 px-5">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
                    <Input
                      value={libraryQuery}
                      onChange={(event) => setLibraryQuery(event.target.value)}
                      className="pl-9"
                      placeholder="搜索框架、材料或类型，例如 IMF、ZSM-5、实测、石英"
                    />
                  </div>
                  <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-muted-foreground">
                    <span>
                      显示 {librarySearchResults.length} 条
                      {librarySearchResults.length === 80
                        ? '（最多 80 条）'
                        : ''}
                    </span>
                    <span>
                      {library?.framework_count} 个结构组 ·{' '}
                      {library?.reference_count} 条参考谱
                    </span>
                  </div>
                </div>
                <div className="max-h-[58vh] overflow-auto border-t px-5 py-3">
                  <div className="space-y-2">
                    {librarySearchResults.map((reference) => (
                      <div
                        key={reference.id}
                        className="grid gap-3 rounded-xl border bg-card p-3 sm:grid-cols-[minmax(0,1fr)_auto] sm:items-center"
                      >
                        <div className="min-w-0">
                          <div className="flex flex-wrap items-center gap-2">
                            <b className="text-base text-primary">
                              {reference.framework}
                            </b>
                            <Badge variant="outline">
                              {kindLabel[reference.kind || ''] ||
                                reference.kind ||
                                '未分类'}
                            </Badge>
                          </div>
                          <div className="mt-1 truncate text-sm">
                            {reference.material || reference.framework}
                          </div>
                          <div className="mt-1 text-xs text-muted-foreground">
                            Cu Kα₁ 等效轴 · {reference.pattern.start.toFixed(2)}
                            –
                            {(
                              reference.pattern.start +
                              (reference.pattern.y.length - 1) *
                                reference.pattern.step
                            ).toFixed(2)}
                            °
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            onClick={() => downloadReferenceTxt(reference)}
                          >
                            <Download /> 下载 TXT
                          </Button>
                          {reference.source && (
                            <Button
                              size="sm"
                              variant="ghost"
                              render={
                                <a
                                  href={reference.source}
                                  target="_blank"
                                  rel="noreferrer"
                                  aria-label={`查看 ${reference.framework} 参考谱来源`}
                                />
                              }
                            >
                              <ExternalLink /> 来源
                            </Button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                  {!librarySearchResults.length && (
                    <div className="grid min-h-40 place-items-center text-center text-muted-foreground">
                      没有找到匹配的标准图谱。
                    </div>
                  )}
                </div>
              </DialogContent>
            </Dialog>
            <Badge variant="secondary" className="hidden sm:flex">
              <Database />{' '}
              {library ? `${library.reference_count} 条参考谱` : '载入参考库…'}
            </Badge>
            <Badge variant="outline" className="hidden md:flex">
              <LockKeyhole /> 数据留在浏览器
            </Badge>
          </div>
        </div>
      </header>

      <div className="mx-auto grid max-w-[1540px] gap-5 px-4 py-5 lg:grid-cols-[310px_minmax(0,1fr)] sm:px-7">
        <aside className="space-y-4">
          <Card className="border-0 shadow-[0_10px_40px_rgba(16,42,67,.08)]">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileUp className="size-4 text-primary" /> 上传实验谱
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <button
                type="button"
                aria-label="选择或拖入 XRD 数据文件"
                onClick={() =>
                  document.getElementById('sample-xrd-file')?.click()
                }
                onDragOver={(event) => event.preventDefault()}
                onDrop={(event) => {
                  event.preventDefault();
                  void handleFile(event.dataTransfer.files[0]);
                }}
                className="group grid min-h-36 cursor-pointer place-items-center rounded-xl border border-dashed border-primary/35 bg-primary/[.035] p-4 text-center transition hover:border-primary hover:bg-primary/[.07]"
              >
                <span>
                  <span className="mx-auto mb-3 grid size-11 place-items-center rounded-full bg-card text-primary shadow-sm">
                    {fileName ? <CheckCircle2 /> : <FileUp />}
                  </span>
                  <span className="block max-w-56 truncate font-medium">
                    {fileName || '选择或拖入 XRD 数据'}
                  </span>
                  <span className="mt-1 block text-xs leading-5 text-muted-foreground">
                    TXT / XY / XYE / CSV · 两列数值
                    <br />
                    2θ 与强度
                  </span>
                </span>
              </button>
              <input
                id="sample-xrd-file"
                type="file"
                accept=".txt,.xy,.xye,.csv,.dat"
                className="sr-only"
                onChange={(event) => void handleFile(event.target.files?.[0])}
              />
              {rawSample.length > 0 && (
                <div className="grid grid-cols-2 gap-2 rounded-lg bg-muted/70 p-3 text-xs">
                  <div>
                    <span className="text-muted-foreground">数据点</span>
                    <b className="mt-1 block text-sm">
                      {rawSample.length.toLocaleString()}
                    </b>
                  </div>
                  <div>
                    <span className="text-muted-foreground">扫描范围</span>
                    <b className="mt-1 block text-sm">{rangeText}</b>
                  </div>
                </div>
              )}
              <div className="space-y-2">
                <Label>实验波长</Label>
                <Select
                  value={wavelengthMode}
                  onValueChange={(value) =>
                    setWavelengthMode(value || '1.5406')
                  }
                >
                  <SelectTrigger className="h-10 w-full">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1.5406">Cu Kα₁ · 1.54060 Å</SelectItem>
                    <SelectItem value="1.5418">Cu Kα₁,₂ · 1.54180 Å</SelectItem>
                    <SelectItem value="custom">自定义波长</SelectItem>
                  </SelectContent>
                </Select>
                {wavelengthMode === 'custom' && (
                  <Input
                    type="number"
                    step="0.00001"
                    value={customWavelength}
                    onChange={(event) =>
                      setCustomWavelength(event.target.value)
                    }
                    aria-label="自定义波长，埃"
                  />
                )}
              </div>
              <div className="space-y-2">
                <Label htmlFor="sample-name">样品名称</Label>
                <Input
                  id="sample-name"
                  value={sampleName}
                  onChange={(event) => setSampleName(event.target.value)}
                  placeholder="例如：IM-5 · 72 h"
                />
              </div>
              <div className="space-y-2">
                <Label>样品状态</Label>
                <Select
                  value={sampleState}
                  onValueChange={(value) => setSampleState(value || 'unknown')}
                >
                  <SelectTrigger className="h-10 w-full">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="unknown">未说明</SelectItem>
                    <SelectItem value="as-made">未焙烧 / as-made</SelectItem>
                    <SelectItem value="calcined">焙烧后</SelectItem>
                    <SelectItem value="hydrated">水合</SelectItem>
                    <SelectItem value="dehydrated">脱水</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Button
                className="h-10 w-full"
                disabled={status === 'analyzing' || !library}
                onClick={() => void analyze()}
              >
                {status === 'analyzing' ? (
                  <LoaderCircle className="animate-spin" />
                ) : (
                  <Play />
                )}{' '}
                开始结构匹配
              </Button>
              <Button
                variant="outline"
                className="h-10 w-full"
                disabled={!library || status === 'analyzing'}
                onClick={() => void loadDemo()}
              >
                <FlaskConical /> 载入 IM-5 示例
              </Button>
              {status === 'analyzing' && (
                <Progress value={progress} className="pt-1" />
              )}
              {error && (
                <div className="flex gap-2 rounded-lg bg-red-50 p-3 text-sm text-red-800">
                  <AlertTriangle className="mt-0.5 size-4 shrink-0" />
                  {error}
                </div>
              )}
            </CardContent>
          </Card>
          <div className="rounded-xl border border-sky-200 bg-sky-50 p-4 text-sm leading-6 text-sky-950">
            <strong className="flex items-center gap-2">
              <Info className="size-4" />
              判读边界
            </strong>
            <span className="mt-1 block text-sky-800">
              结果是候选结构排序，不是自动定论。相对结晶度必须另用同条件实体标样。
            </span>
          </div>
        </aside>

        <section className="min-w-0 space-y-5">
          <Card className="border-0 shadow-[0_10px_40px_rgba(16,42,67,.08)]">
            <CardHeader className="border-b border-border/70">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <CardTitle>实验谱与候选结构叠加</CardTitle>
                <div className="flex items-center gap-2">
                  {selected && (
                    <Badge variant="secondary">
                      Δ2θ {selected.shift >= 0 ? '+' : ''}
                      {selected.shift.toFixed(2)}°
                    </Badge>
                  )}
                  <Badge variant="outline">5–45° 2θ</Badge>
                </div>
              </div>
            </CardHeader>
            <CardContent className="pt-4">
              {samplePlot.length ? (
                <XrdPlot
                  sample={samplePlot}
                  reference={referencePlot}
                  result={selected}
                />
              ) : (
                <div className="relative grid h-[330px] place-items-center overflow-hidden rounded-xl bg-[#071525] text-center">
                  <div>
                    <ScanLine className="mx-auto mb-3 size-9 text-cyan-400/70" />
                    <p className="text-[#c7d9ea]">
                      上传谱图或载入示例后显示匹配结果
                    </p>
                    <p className="mt-1 text-xs text-[#6f8da9]">
                      整谱相似度 · 特征峰覆盖 · 未解释峰
                    </p>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          <div className="grid gap-5 xl:grid-cols-[minmax(0,1.2fr)_minmax(350px,.8fr)]">
            <Card className="border-0 shadow-[0_10px_40px_rgba(16,42,67,.08)]">
              <CardHeader className="border-b border-border/70">
                <div className="flex items-center justify-between">
                  <CardTitle>候选结构</CardTitle>
                  {results.length > 0 && (
                    <Button size="sm" variant="outline" onClick={exportReport}>
                      <Download /> 导出报告
                    </Button>
                  )}
                </div>
              </CardHeader>
              <CardContent className="pt-3">
                {results.length ? (
                  <div className="space-y-2">
                    {results.slice(0, 6).map((result, index) => (
                      <button
                        key={result.framework}
                        onClick={() => setSelectedIndex(index)}
                        className={`grid w-full grid-cols-[38px_minmax(0,1fr)_74px] items-center gap-3 rounded-xl border p-3 text-left transition ${selectedIndex === index ? 'border-primary/45 bg-primary/[.055] shadow-sm' : 'border-transparent bg-muted/45 hover:border-border hover:bg-muted'}`}
                      >
                        <span
                          className={`grid size-8 place-items-center rounded-lg text-sm font-semibold ${index === 0 ? 'bg-primary text-white' : 'bg-card text-muted-foreground shadow-sm'}`}
                        >
                          {index + 1}
                        </span>
                        <span className="min-w-0">
                          <span className="flex items-center gap-2">
                            <b className="text-base">{result.framework}</b>
                            <Badge
                              variant={
                                result.confidence === '很可能'
                                  ? 'default'
                                  : 'outline'
                              }
                            >
                              {result.confidence}
                            </Badge>
                          </span>
                          <span className="mt-1 block truncate text-xs text-muted-foreground">
                            {result.material} ·{' '}
                            {kindLabel[result.reference.kind || ''] ||
                              result.reference.kind}
                          </span>
                          <span className="mt-2 grid grid-cols-3 gap-2 text-[11px] text-muted-foreground">
                            <span>
                              整谱 {(result.cosine * 100).toFixed(0)}%
                            </span>
                            <span>
                              预期峰{' '}
                              {(result.expectedCoverage * 100).toFixed(0)}%
                            </span>
                            <span>
                              解释峰 {(result.sampleExplained * 100).toFixed(0)}
                              %
                            </span>
                          </span>
                        </span>
                        <span className="text-right">
                          <b className="text-xl tabular-nums text-primary">
                            {result.score.toFixed(1)}
                          </b>
                          <span className="block text-[10px] text-muted-foreground">
                            排序评分
                          </span>
                        </span>
                      </button>
                    ))}
                  </div>
                ) : (
                  <div className="grid min-h-64 place-items-center rounded-xl border border-dashed text-center text-muted-foreground">
                    <div>
                      <Database className="mx-auto mb-3 size-7" />
                      <p>完成分析后显示候选框架</p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            <div className="space-y-5">
              <Card className="border-0 shadow-[0_10px_40px_rgba(16,42,67,.08)]">
                <CardHeader className="border-b border-border/70">
                  <div className="flex items-center justify-between gap-3">
                    <CardTitle className="flex items-center gap-2">
                      <Atom className="size-4 text-primary" /> CIF 骨架示意
                    </CardTitle>
                    {structureOptions.length > 1 && (
                      <Select
                        value={activeCif}
                        onValueChange={(value) => setSelectedCif(value || '')}
                      >
                        <SelectTrigger className="max-w-44">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {structureOptions.map((option) => (
                            <SelectItem key={option.path} value={option.path}>
                              {option.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    )}
                  </div>
                </CardHeader>
                <CardContent className="pt-4">
                  <CifViewer
                    path={activeCif}
                    label={
                      structureOptions.find(
                        (option) => option.path === activeCif,
                      )?.label || selected?.framework
                    }
                  />
                </CardContent>
              </Card>

              {selected && (
                <Card className="border-0 shadow-[0_10px_40px_rgba(16,42,67,.08)]">
                  <CardHeader>
                    <CardTitle>峰与证据</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="mb-4 flex flex-wrap items-center justify-between gap-3 rounded-xl border border-primary/20 bg-primary/[.045] p-3">
                      <div className="min-w-0">
                        <b className="block truncate">
                          {selected.framework} · {selected.material}
                        </b>
                        <span className="mt-0.5 block text-xs text-muted-foreground">
                          {kindLabel[selected.reference.kind || ''] ||
                            selected.reference.kind}{' '}
                          · Cu Kα₁ 等效轴
                        </span>
                      </div>
                      <Button
                        size="sm"
                        onClick={() => downloadReferenceTxt(selected.reference)}
                      >
                        <Download /> 下载参考谱 TXT
                      </Button>
                    </div>
                    <Tabs defaultValue="matched">
                      <TabsList className="w-full">
                        <TabsTrigger value="matched">
                          匹配峰 {selected.matchedPeaks.length}
                        </TabsTrigger>
                        <TabsTrigger value="missing">
                          缺失峰 {selected.missingPeaks.length}
                        </TabsTrigger>
                        <TabsTrigger value="extra">
                          未解释 {selected.unexplainedPeaks.length}
                        </TabsTrigger>
                      </TabsList>
                      <TabsContent value="matched" className="pt-3">
                        <div className="max-h-44 overflow-auto rounded-lg border">
                          <table className="w-full text-xs">
                            <thead className="sticky top-0 bg-muted">
                              <tr>
                                <th className="p-2 text-left">参考 2θ</th>
                                <th className="p-2 text-left">实验 2θ</th>
                                <th className="p-2 text-right">偏差</th>
                              </tr>
                            </thead>
                            <tbody>
                              {selected.matchedPeaks
                                .slice(0, 20)
                                .map((peak) => (
                                  <tr
                                    key={`${peak.expected}-${peak.observed}`}
                                    className="border-t"
                                  >
                                    <td className="p-2">
                                      {peak.expected.toFixed(2)}°
                                    </td>
                                    <td className="p-2">
                                      {peak.observed.toFixed(2)}°
                                    </td>
                                    <td className="p-2 text-right">
                                      {peak.delta >= 0 ? '+' : ''}
                                      {peak.delta.toFixed(2)}°
                                    </td>
                                  </tr>
                                ))}
                            </tbody>
                          </table>
                        </div>
                      </TabsContent>
                      <TabsContent
                        value="missing"
                        className="pt-3 text-sm leading-7 text-muted-foreground"
                      >
                        {selected.missingPeaks.length
                          ? selected.missingPeaks
                              .slice(0, 24)
                              .map((x) => x.toFixed(2))
                              .join('° · ') + '°'
                          : '未发现明显缺失的参考峰。'}
                      </TabsContent>
                      <TabsContent
                        value="extra"
                        className="pt-3 text-sm leading-7 text-muted-foreground"
                      >
                        {selected.unexplainedPeaks.length
                          ? selected.unexplainedPeaks
                              .slice(0, 24)
                              .map((x) => x.toFixed(2))
                              .join('° · ') + '°'
                          : '主要实验峰均得到解释。'}
                      </TabsContent>
                    </Tabs>
                    {selected.reference.source && (
                      <a
                        href={selected.reference.source}
                        target="_blank"
                        rel="noreferrer"
                        className="mt-3 flex items-center gap-1 text-xs text-primary hover:underline"
                      >
                        查看 IZA/COD 来源 <ExternalLink className="size-3" />
                      </a>
                    )}
                  </CardContent>
                </Card>
              )}
            </div>
          </div>

          <MultiPhasePanel sample={analysisSample} library={library} />
          <CrystallinityPanel
            sample={rawSample}
            sampleName={sampleName || fileName}
          />
        </section>
      </div>
      <footer className="mx-auto max-w-[1540px] px-4 pb-7 text-center text-xs leading-5 text-muted-foreground sm:px-7">
        XRD 匹配用于候选结构筛查。不能仅凭本结果判断
        Si/Al、杂原子入骨架、酸性、孔道性能或相含量。
      </footer>
    </main>
  );
}
