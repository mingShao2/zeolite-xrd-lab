export type Point = { x: number; y: number };

export type CompactPattern = {
  start: number;
  step: number;
  y: number[];
};

export type ReferenceRecord = {
  id: string;
  framework: string;
  material?: string;
  kind?: string;
  state?: string;
  source?: string;
  wavelength_angstrom: number;
  source_wavelength_angstrom?: number;
  polymorph_ratio?: Record<string, number>;
  pattern: CompactPattern;
};

export type StructureOption = { label: string; path: string };

export type ReferenceLibrary = {
  version: number;
  comparison_wavelength_angstrom: number;
  reference_count: number;
  framework_count: number;
  references: ReferenceRecord[];
  structures: Record<string, StructureOption[]>;
  notes: string[];
};

export type MatchResult = {
  reference: ReferenceRecord;
  framework: string;
  material: string;
  score: number;
  cosine: number;
  expectedCoverage: number;
  sampleExplained: number;
  shift: number;
  confidence: '很可能' | '可能' | '待确认';
  matchedPeaks: Array<{ expected: number; observed: number; delta: number }>;
  missingPeaks: number[];
  unexplainedPeaks: number[];
};

const isFiniteNumber = (value: number) => Number.isFinite(value);

export function parseXrdText(text: string): Point[] {
  const points: Point[] = [];
  for (const raw of text.split(/\r?\n/)) {
    const line = raw.trim();
    if (!line || /^[#!;]/.test(line)) continue;
    const fields = line.replace(/,/g, ' ').split(/\s+/);
    if (fields.length < 2) continue;
    const x = Number(fields[0]);
    const y = Number(fields[1]);
    if (isFiniteNumber(x) && isFiniteNumber(y)) points.push({ x, y });
  }
  points.sort((a, b) => a.x - b.x);
  const merged: Point[] = [];
  for (const point of points) {
    const previous = merged[merged.length - 1];
    if (previous && Math.abs(previous.x - point.x) < 1e-8) previous.y = (previous.y + point.y) / 2;
    else merged.push({ ...point });
  }
  if (merged.length < 20) throw new Error('未识别到足够的数据点，请确认文件至少包含两列数值：2θ 和强度。');
  return merged;
}

export function convertWavelength(points: Point[], source: number, target: number): Point[] {
  if (!source || !target || Math.abs(source - target) < 1e-7) return points.map((p) => ({ ...p }));
  return points.flatMap((point) => {
    const argument = (target / source) * Math.sin((point.x * Math.PI) / 360);
    if (Math.abs(argument) > 1) return [];
    return [{ x: (360 / Math.PI) * Math.asin(argument), y: point.y }];
  });
}

function referencePoints(pattern: CompactPattern): Point[] {
  return pattern.y.map((y, index) => ({ x: pattern.start + index * pattern.step, y }));
}

function interpolate(points: Point[], x: number): number {
  if (x < points[0].x || x > points[points.length - 1].x) return 0;
  let lo = 0;
  let hi = points.length - 1;
  while (hi - lo > 1) {
    const mid = (lo + hi) >> 1;
    if (points[mid].x <= x) lo = mid;
    else hi = mid;
  }
  const left = points[lo];
  const right = points[hi];
  if (right.x === left.x) return left.y;
  return left.y + ((right.y - left.y) * (x - left.x)) / (right.x - left.x);
}

function sampleOnGrid(points: Point[], start: number, end: number, step: number, shift = 0): number[] {
  const count = Math.floor((end - start) / step) + 1;
  return Array.from({ length: count }, (_, index) => interpolate(points, start + index * step - shift));
}

function movingAverage(values: number[], radius: number): number[] {
  if (radius <= 0) return [...values];
  const prefix = [0];
  for (const value of values) prefix.push(prefix[prefix.length - 1] + value);
  return values.map((_, index) => {
    const left = Math.max(0, index - radius);
    const right = Math.min(values.length, index + radius + 1);
    return (prefix[right] - prefix[left]) / (right - left);
  });
}

function rollingMin(values: number[], radius: number): number[] {
  return values.map((_, index) => {
    let minimum = Infinity;
    for (let i = Math.max(0, index - radius); i <= Math.min(values.length - 1, index + radius); i++) minimum = Math.min(minimum, values[i]);
    return minimum;
  });
}

function preprocess(values: number[], step: number): number[] {
  const baselineRadius = Math.max(2, Math.round(1.6 / step / 2));
  const smoothRadius = Math.max(1, Math.round(0.06 / step / 2));
  const baseline = movingAverage(rollingMin(values, baselineRadius), Math.max(1, Math.round(baselineRadius / 5)));
  return movingAverage(values.map((value, i) => Math.max(0, value - baseline[i])), smoothRadius);
}

function normalize(values: number[]): number[] {
  const norm = Math.sqrt(values.reduce((sum, value) => sum + value * value, 0));
  return norm ? values.map((value) => value / norm) : values.map(() => 0);
}

function cosine(left: number[], right: number[]): number {
  const a = normalize(left);
  const b = normalize(right);
  return a.reduce((sum, value, index) => sum + value * b[index], 0);
}

export function detectPeaks(start: number, step: number, values: number[], relative = 0.045, minDistance = 0.18) {
  const maximum = Math.max(...values);
  const cutoff = maximum * relative;
  const candidates: Array<{ x: number; y: number }> = [];
  for (let i = 2; i < values.length - 2; i++) {
    if (values[i] >= cutoff && values[i] >= values[i - 1] && values[i] > values[i + 1]) {
      const localFloor = Math.max(Math.min(values[i - 2], values[i - 1]), Math.min(values[i + 1], values[i + 2]));
      if (values[i] - localFloor > cutoff * 0.08) candidates.push({ x: start + i * step, y: values[i] });
    }
  }
  candidates.sort((a, b) => b.y - a.y);
  const selected: typeof candidates = [];
  for (const peak of candidates) if (selected.every((other) => Math.abs(other.x - peak.x) >= minDistance)) selected.push(peak);
  return selected.sort((a, b) => a.x - b.x);
}

function peakCoverage(expected: Array<{ x: number; y: number }>, observed: Array<{ x: number; y: number }>, tolerance: number) {
  const total = expected.reduce((sum, peak) => sum + peak.y, 0) || 1;
  let matchedWeight = 0;
  const matched: Array<{ expected: number; observed: number; delta: number }> = [];
  const missing: number[] = [];
  for (const peak of expected) {
    const candidates = observed.filter((other) => Math.abs(other.x - peak.x) <= tolerance);
    if (candidates.length) {
      const nearest = candidates.reduce((best, current) => Math.abs(current.x - peak.x) < Math.abs(best.x - peak.x) ? current : best);
      matchedWeight += peak.y;
      matched.push({ expected: peak.x, observed: nearest.x, delta: nearest.x - peak.x });
    } else missing.push(peak.x);
  }
  return { coverage: matchedWeight / total, matched, missing };
}

export function analyzePattern(sample: Point[], library: ReferenceLibrary): MatchResult[] {
  const step = 0.04;
  const scored: MatchResult[] = [];
  for (const reference of library.references) {
    const refPoints = referencePoints(reference.pattern);
    const start = Math.max(5, sample[0].x, refPoints[0].x);
    const end = Math.min(45, sample[sample.length - 1].x, refPoints[refPoints.length - 1].x);
    if (end - start < 8) continue;
    const sampleValues = preprocess(sampleOnGrid(sample, start, end, step), step);
    const samplePeaks = detectPeaks(start, step, sampleValues);
    let bestCosine = -1;
    let bestShift = 0;
    let bestReference: number[] = [];
    for (let shift = -0.24; shift <= 0.2401; shift += 0.04) {
      const values = preprocess(sampleOnGrid(refPoints, start, end, step, shift), step);
      const value = cosine(sampleValues, values);
      if (value > bestCosine) { bestCosine = value; bestShift = shift; bestReference = values; }
    }
    const refPeaks = detectPeaks(start, step, bestReference).map((peak) => ({ ...peak, x: peak.x }));
    const expected = peakCoverage(refPeaks, samplePeaks, 0.2);
    const explained = peakCoverage(samplePeaks, refPeaks, 0.2);
    const score = 100 * (0.5 * Math.max(0, bestCosine) + 0.3 * expected.coverage + 0.2 * explained.coverage);
    const confidence = score >= 80 && expected.coverage >= 0.72 && explained.coverage >= 0.65 ? '很可能' : score >= 63 && expected.coverage >= 0.5 ? '可能' : '待确认';
    scored.push({
      reference,
      framework: reference.framework,
      material: reference.material || reference.framework,
      score,
      cosine: bestCosine,
      expectedCoverage: expected.coverage,
      sampleExplained: explained.coverage,
      shift: bestShift,
      confidence,
      matchedPeaks: expected.matched,
      missingPeaks: expected.missing,
      unexplainedPeaks: explained.missing,
    });
  }
  scored.sort((a, b) => b.score - a.score);
  const unique = new Map<string, MatchResult>();
  for (const result of scored) if (!unique.has(result.framework)) unique.set(result.framework, result);
  return [...unique.values()].slice(0, 10);
}

export function materializePattern(pattern: CompactPattern): Point[] {
  return referencePoints(pattern);
}

export function normalizedForPlot(points: Point[], start = 5, end = 45): Point[] {
  const selected = points.filter((point) => point.x >= start && point.x <= end);
  const maximum = Math.max(...selected.map((point) => point.y), 1);
  const stride = Math.max(1, Math.floor(selected.length / 1200));
  return selected.filter((_, index) => index % stride === 0).map((point) => ({ x: point.x, y: (100 * point.y) / maximum }));
}
