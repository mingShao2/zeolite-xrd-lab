export type Point = { x: number; y: number };

export type CompactPattern = {
  start: number;
  step: number;
  y: number[];
};

export type ReferenceRecord = {
  id: string;
  framework: string;
  material?: string;
  kind?: string;
  state?: string;
  source?: string;
  wavelength_angstrom: number;
  source_wavelength_angstrom?: number;
  source_radiation?: string;
  radiation?: string;
  download_date?: string;
  range_2theta_deg?: number[];
  notes?: string;
  polymorph_ratio?: Record<string, number>;
  pattern: CompactPattern;
};

export type StructureOption = { label: string; path: string };

export type ReferenceLibrary = {
  version: number;
  comparison_wavelength_angstrom: number;
  reference_count: number;
  framework_count: number;
  references: ReferenceRecord[];
  structures: Record<string, StructureOption[]>;
  notes: string[];
};

export type MatchResult = {
  reference: ReferenceRecord;
  framework: string;
  material: string;
  score: number;
  cosine: number;
  expectedCoverage: number;
  sampleExplained: number;
  shift: number;
  confidence: '很可能' | '可能' | '待确认';
  matchedPeaks: Array<{ expected: number; observed: number; delta: number }>;
  missingPeaks: number[];
  unexplainedPeaks: number[];
};

export type IntegrationWindow = { start: number; end: number; label?: string };

export type CrystallinityWindowResult = IntegrationWindow & {
  sampleArea: number;
  referenceArea: number;
  ratioPercent: number;
};

export type RelativeCrystallinityResult = {
  relativeCrystallinity: number;
  sampleArea: number;
  referenceArea: number;
  windows: CrystallinityWindowResult[];
};

export type PhaseEvidence = {
  framework: string;
  material: string;
  evidence: '较强' | '可能' | '弱' | '未见明显证据';
  score: number;
  expectedCoverage: number;
  matchedPeakCount: number;
  contributionIndex: number;
  shift: number;
  reference: ReferenceRecord;
};

export type PeakAssignment = {
  position: number;
  relativeIntensity: number;
  assignments: Array<{
    framework: string;
    referencePeak: number;
    delta: number;
  }>;
};

export type MultiPhaseResult = {
  phases: PhaseEvidence[];
  peakAssignments: PeakAssignment[];
  amorphous: {
    level: '未见明显宽峰' | '弱宽峰提示' | '中等宽峰提示' | '较强宽峰提示';
    broadSignalIndex: number;
    center: number | null;
    note: string;
  };
};

const isFiniteNumber = (value: number) => Number.isFinite(value);

export function parseXrdText(text: string): Point[] {
  const points: Point[] = [];
  for (const raw of text.split(/\r?\n/)) {
    const line = raw.trim();
    if (!line || /^[#!;]/.test(line)) continue;
    const fields = line.replace(/,/g, ' ').split(/\s+/);
    if (fields.length < 2) continue;
    const x = Number(fields[0]);
    const y = Number(fields[1]);
    if (isFiniteNumber(x) && isFiniteNumber(y)) points.push({ x, y });
  }
  points.sort((a, b) => a.x - b.x);
  const merged: Point[] = [];
  for (const point of points) {
    const previous = merged[merged.length - 1];
    if (previous && Math.abs(previous.x - point.x) < 1e-8)
      previous.y = (previous.y + point.y) / 2;
    else merged.push({ ...point });
  }
  if (merged.length < 20)
    throw new Error(
      '未识别到足够的数据点，请确认文件至少包含两列数值：2θ 和强度。',
    );
  return merged;
}

export function convertWavelength(
  points: Point[],
  source: number,
  target: number,
): Point[] {
  if (!source || !target || Math.abs(source - target) < 1e-7)
    return points.map((p) => ({ ...p }));
  return points.flatMap((point) => {
    const argument = (target / source) * Math.sin((point.x * Math.PI) / 360);
    if (Math.abs(argument) > 1) return [];
    return [{ x: (360 / Math.PI) * Math.asin(argument), y: point.y }];
  });
}

function referencePoints(pattern: CompactPattern): Point[] {
  return pattern.y.map((y, index) => ({
    x: pattern.start + index * pattern.step,
    y,
  }));
}

function interpolate(points: Point[], x: number): number {
  if (x < points[0].x || x > points[points.length - 1].x) return 0;
  let lo = 0;
  let hi = points.length - 1;
  while (hi - lo > 1) {
    const mid = (lo + hi) >> 1;
    if (points[mid].x <= x) lo = mid;
    else hi = mid;
  }
  const left = points[lo];
  const right = points[hi];
  if (right.x === left.x) return left.y;
  return left.y + ((right.y - left.y) * (x - left.x)) / (right.x - left.x);
}

function sampleOnGrid(
  points: Point[],
  start: number,
  end: number,
  step: number,
  shift = 0,
): number[] {
  const count = Math.floor((end - start) / step) + 1;
  return Array.from({ length: count }, (_, index) =>
    interpolate(points, start + index * step - shift),
  );
}

function movingAverage(values: number[], radius: number): number[] {
  if (radius <= 0) return [...values];
  const prefix = [0];
  for (const value of values) prefix.push(prefix[prefix.length - 1] + value);
  return values.map((_, index) => {
    const left = Math.max(0, index - radius);
    const right = Math.min(values.length, index + radius + 1);
    return (prefix[right] - prefix[left]) / (right - left);
  });
}

function rollingMin(values: number[], radius: number): number[] {
  return values.map((_, index) => {
    let minimum = Infinity;
    for (
      let i = Math.max(0, index - radius);
      i <= Math.min(values.length - 1, index + radius);
      i++
    )
      minimum = Math.min(minimum, values[i]);
    return minimum;
  });
}

function preprocess(values: number[], step: number): number[] {
  const baselineRadius = Math.max(2, Math.round(1.6 / step / 2));
  const smoothRadius = Math.max(1, Math.round(0.06 / step / 2));
  const baseline = movingAverage(
    rollingMin(values, baselineRadius),
    Math.max(1, Math.round(baselineRadius / 5)),
  );
  return movingAverage(
    values.map((value, i) => Math.max(0, value - baseline[i])),
    smoothRadius,
  );
}

function normalize(values: number[]): number[] {
  const norm = Math.sqrt(values.reduce((sum, value) => sum + value * value, 0));
  return norm ? values.map((value) => value / norm) : values.map(() => 0);
}

function cosine(left: number[], right: number[]): number {
  const a = normalize(left);
  const b = normalize(right);
  return a.reduce((sum, value, index) => sum + value * b[index], 0);
}

export function detectPeaks(
  start: number,
  step: number,
  values: number[],
  relative = 0.045,
  minDistance = 0.18,
) {
  const maximum = Math.max(...values);
  const cutoff = maximum * relative;
  const candidates: Array<{ x: number; y: number }> = [];
  for (let i = 2; i < values.length - 2; i++) {
    if (
      values[i] >= cutoff &&
      values[i] >= values[i - 1] &&
      values[i] > values[i + 1]
    ) {
      const localFloor = Math.max(
        Math.min(values[i - 2], values[i - 1]),
        Math.min(values[i + 1], values[i + 2]),
      );
      if (values[i] - localFloor > cutoff * 0.08)
        candidates.push({ x: start + i * step, y: values[i] });
    }
  }
  candidates.sort((a, b) => b.y - a.y);
  const selected: typeof candidates = [];
  for (const peak of candidates)
    if (selected.every((other) => Math.abs(other.x - peak.x) >= minDistance))
      selected.push(peak);
  return selected.sort((a, b) => a.x - b.x);
}

function peakCoverage(
  expected: Array<{ x: number; y: number }>,
  observed: Array<{ x: number; y: number }>,
  tolerance: number,
) {
  const total = expected.reduce((sum, peak) => sum + peak.y, 0) || 1;
  let matchedWeight = 0;
  const matched: Array<{ expected: number; observed: number; delta: number }> =
    [];
  const missing: number[] = [];
  for (const peak of expected) {
    const candidates = observed.filter(
      (other) => Math.abs(other.x - peak.x) <= tolerance,
    );
    if (candidates.length) {
      const nearest = candidates.reduce((best, current) =>
        Math.abs(current.x - peak.x) < Math.abs(best.x - peak.x)
          ? current
          : best,
      );
      matchedWeight += peak.y;
      matched.push({
        expected: peak.x,
        observed: nearest.x,
        delta: nearest.x - peak.x,
      });
    } else missing.push(peak.x);
  }
  return { coverage: matchedWeight / total, matched, missing };
}

export function analyzePattern(
  sample: Point[],
  library: ReferenceLibrary,
  maxResults = 10,
): MatchResult[] {
  const step = 0.04;
  const scored: MatchResult[] = [];
  for (const reference of library.references) {
    const refPoints = referencePoints(reference.pattern);
    const start = Math.max(5, sample[0].x, refPoints[0].x);
    const end = Math.min(
      45,
      sample[sample.length - 1].x,
      refPoints[refPoints.length - 1].x,
    );
    if (end - start < 8) continue;
    const sampleValues = preprocess(
      sampleOnGrid(sample, start, end, step),
      step,
    );
    const samplePeaks = detectPeaks(start, step, sampleValues);
    let bestCosine = -1;
    let bestShift = 0;
    let bestReference: number[] = [];
    for (let shift = -0.24; shift <= 0.2401; shift += 0.04) {
      const values = preprocess(
        sampleOnGrid(refPoints, start, end, step, shift),
        step,
      );
      const value = cosine(sampleValues, values);
      if (value > bestCosine) {
        bestCosine = value;
        bestShift = shift;
        bestReference = values;
      }
    }
    const refPeaks = detectPeaks(start, step, bestReference).map((peak) => ({
      ...peak,
      x: peak.x,
    }));
    const expected = peakCoverage(refPeaks, samplePeaks, 0.2);
    const explained = peakCoverage(samplePeaks, refPeaks, 0.2);
    const score =
      100 *
      (0.5 * Math.max(0, bestCosine) +
        0.3 * expected.coverage +
        0.2 * explained.coverage);
    const confidence =
      score >= 80 && expected.coverage >= 0.72 && explained.coverage >= 0.65
        ? '很可能'
        : score >= 63 && expected.coverage >= 0.5
          ? '可能'
          : '待确认';
    scored.push({
      reference,
      framework: reference.framework,
      material: reference.material || reference.framework,
      score,
      cosine: bestCosine,
      expectedCoverage: expected.coverage,
      sampleExplained: explained.coverage,
      shift: bestShift,
      confidence,
      matchedPeaks: expected.matched,
      missingPeaks: expected.missing,
      unexplainedPeaks: explained.missing,
    });
  }
  scored.sort((a, b) => b.score - a.score);
  const unique = new Map<string, MatchResult>();
  for (const result of scored)
    if (!unique.has(result.framework)) unique.set(result.framework, result);
  return [...unique.values()].slice(0, maxResults);
}

function medianStep(points: Point[]) {
  const differences = points
    .slice(1)
    .map((point, index) => point.x - points[index].x)
    .filter((value) => value > 0 && value < 1)
    .sort((a, b) => a - b);
  return differences.length
    ? differences[Math.floor(differences.length / 2)]
    : 0.04;
}

function integrateNetArea(points: Point[], start: number, end: number) {
  const step = Math.max(0.005, Math.min(0.04, medianStep(points)));
  const values = sampleOnGrid(points, start, end, step);
  if (values.length < 4)
    throw new Error(
      `积分区间 ${start.toFixed(2)}–${end.toFixed(2)}° 内数据点不足。`,
    );
  const first = values[0];
  const last = values[values.length - 1];
  const net = values.map((value, index) => {
    const baseline = first + ((last - first) * index) / (values.length - 1);
    return Math.max(0, value - baseline);
  });
  let area = 0;
  for (let index = 1; index < net.length; index++)
    area += ((net[index - 1] + net[index]) * step) / 2;
  return area;
}

export function parseIntegrationWindows(text: string): IntegrationWindow[] {
  const windows = text
    .split(/[,，;；\n]+/)
    .map((part) => part.trim())
    .filter(Boolean)
    .map((part, index) => {
      const match = part.match(
        /^(\d+(?:\.\d+)?)\s*(?:-|\u2013|\u2014|~|至)\s*(\d+(?:\.\d+)?)$/,
      );
      if (!match)
        throw new Error(`无法识别第 ${index + 1} 个积分区间：${part}`);
      const start = Number(match[1]);
      const end = Number(match[2]);
      if (end - start < 0.1)
        throw new Error(`积分区间 ${part} 过窄或顺序错误。`);
      return { start, end, label: `W${index + 1}` };
    })
    .sort((left, right) => left.start - right.start);
  if (!windows.length) throw new Error('请至少输入一个积分区间。');
  for (let index = 1; index < windows.length; index++)
    if (windows[index].start < windows[index - 1].end)
      throw new Error('积分区间不应相互重叠。');
  return windows;
}

export function suggestIntegrationWindows(
  sample: Point[],
  reference: Point[],
  count = 6,
): IntegrationWindow[] {
  const start = Math.max(sample[0].x, reference[0].x, 5);
  const end = Math.min(
    sample[sample.length - 1].x,
    reference[reference.length - 1].x,
    45,
  );
  if (end - start < 8) throw new Error('样品与实体标样的共同扫描范围不足。');
  const step = 0.04;
  const processed = preprocess(sampleOnGrid(reference, start, end, step), step);
  const peaks = detectPeaks(start, step, processed, 0.07, 0.55).sort(
    (left, right) => right.y - left.y,
  );
  const selected: typeof peaks = [];
  for (const peak of peaks) {
    if (selected.every((other) => Math.abs(other.x - peak.x) >= 0.75))
      selected.push(peak);
    if (selected.length >= count) break;
  }
  if (!selected.length)
    throw new Error('未能从实体标样谱中自动选出特征峰，请改用手动积分区间。');
  return selected
    .map((peak, index) => ({
      start: Math.max(start, peak.x - 0.32),
      end: Math.min(end, peak.x + 0.32),
      label: `P${index + 1} ${peak.x.toFixed(2)}°`,
    }))
    .sort((left, right) => left.start - right.start);
}

export function calculateRelativeCrystallinity(
  sample: Point[],
  reference: Point[],
  windows: IntegrationWindow[],
): RelativeCrystallinityResult {
  if (!sample.length || !reference.length)
    throw new Error('样品谱和实体标样谱都必须上传。');
  const commonStart = Math.max(sample[0].x, reference[0].x);
  const commonEnd = Math.min(
    sample[sample.length - 1].x,
    reference[reference.length - 1].x,
  );
  const checked = windows.map((window) => {
    if (window.start < commonStart || window.end > commonEnd)
      throw new Error(
        `积分区间 ${window.start.toFixed(2)}–${window.end.toFixed(2)}° 超出两条谱的共同范围 ${commonStart.toFixed(2)}–${commonEnd.toFixed(2)}°。`,
      );
    const sampleArea = integrateNetArea(sample, window.start, window.end);
    const referenceArea = integrateNetArea(reference, window.start, window.end);
    return {
      ...window,
      sampleArea,
      referenceArea,
      ratioPercent:
        referenceArea > 0 ? (100 * sampleArea) / referenceArea : Number.NaN,
    };
  });
  const sampleArea = checked.reduce(
    (sum, window) => sum + window.sampleArea,
    0,
  );
  const referenceArea = checked.reduce(
    (sum, window) => sum + window.referenceArea,
    0,
  );
  if (!(referenceArea > 0))
    throw new Error('实体标样在所选区间的净峰面积为 0，请检查区间或原始数据。');
  return {
    relativeCrystallinity: (100 * sampleArea) / referenceArea,
    sampleArea,
    referenceArea,
    windows: checked,
  };
}

function normalizedFramework(value: string) {
  const compact = value
    .trim()
    .toLowerCase()
    .replace(/[α \s_]+/g, '-')
    .replace(/-+/g, '-');
  if (['quartz', 'alpha-quartz', '石英', '二氧化硅'].includes(compact))
    return 'alpha-quartz';
  return value.trim().toUpperCase();
}

function estimateAmorphousSignal(sample: Point[]) {
  const start = Math.max(10, sample[0].x);
  const end = Math.min(38, sample[sample.length - 1].x);
  if (end - start < 8)
    return {
      level: '未见明显宽峰' as const,
      broadSignalIndex: 0,
      center: null,
      note: '扫描范围不足，无法评估宽峰背景。',
    };
  const step = 0.04;
  const raw = sampleOnGrid(sample, start, end, step);
  const minimum = Math.min(...raw);
  const shifted = raw.map((value) => Math.max(0, value - minimum));
  const floor = movingAverage(
    rollingMin(shifted, Math.round(0.7 / step)),
    Math.round(0.22 / step),
  );
  const edge = Math.max(3, Math.round(0.5 / step));
  const left =
    floor.slice(0, edge).reduce((sum, value) => sum + value, 0) / edge;
  const right =
    floor.slice(-edge).reduce((sum, value) => sum + value, 0) / edge;
  const broad = floor.map((value, index) =>
    Math.max(0, value - left - ((right - left) * index) / (floor.length - 1)),
  );
  const broadArea = broad.reduce((sum, value) => sum + value, 0);
  const totalArea = shifted.reduce((sum, value) => sum + value, 0) || 1;
  const index = Math.min(1, broadArea / totalArea);
  const centerIndex = broad.reduce(
    (best, value, position) => (value > broad[best] ? position : best),
    0,
  );
  const center = broadArea > 0 ? start + centerIndex * step : null;
  const level: MultiPhaseResult['amorphous']['level'] =
    index >= 0.34
      ? '较强宽峰提示'
      : index >= 0.18
        ? '中等宽峰提示'
        : index >= 0.07
          ? '弱宽峰提示'
          : '未见明显宽峰';
  return {
    level,
    broadSignalIndex: index,
    center,
    note: '该指标只是宽弥散峰背景提示，不是无定形相含量；倾斜背景、荧光和峰展宽也可能导致升高。',
  };
}

export function analyzeMultiPhase(
  sample: Point[],
  library: ReferenceLibrary,
  requestedFrameworks: string[],
): MultiPhaseResult {
  const ranked = analyzePattern(
    sample,
    library,
    Math.max(library.reference_count, library.framework_count),
  );
  const byFramework = new Map(
    ranked.map((result) => [result.framework.toLowerCase(), result]),
  );
  const requested = [
    ...new Set(requestedFrameworks.map(normalizedFramework).filter(Boolean)),
  ];
  const selectedResults = requested
    .map((framework) => byFramework.get(framework.toLowerCase()))
    .filter((result): result is MatchResult => Boolean(result));
  if (!selectedResults.length)
    throw new Error('所选多物相在当前参考谱库中没有可用图谱。');
  const fitStart = Math.max(
    5,
    sample[0].x,
    ...selectedResults.map((result) => result.reference.pattern.start),
  );
  const fitEnd = Math.min(
    45,
    sample[sample.length - 1].x,
    ...selectedResults.map(
      (result) =>
        result.reference.pattern.start +
        (result.reference.pattern.y.length - 1) * result.reference.pattern.step,
    ),
  );
  if (fitEnd - fitStart < 8)
    throw new Error('样品与所选物相参考谱的共同范围不足。');
  const fitStep = 0.04;
  const target = normalize(
    preprocess(sampleOnGrid(sample, fitStart, fitEnd, fitStep), fitStep),
  );
  const profiles = selectedResults.map((result) =>
    normalize(
      preprocess(
        sampleOnGrid(
          referencePoints(result.reference.pattern),
          fitStart,
          fitEnd,
          fitStep,
          result.shift,
        ),
        fitStep,
      ),
    ),
  );
  const coefficients = profiles.map(() => 0);
  for (let iteration = 0; iteration < 160; iteration++) {
    for (let component = 0; component < profiles.length; component++) {
      let numerator = 0;
      let denominator = 0;
      for (let index = 0; index < target.length; index++) {
        let other = 0;
        for (let candidate = 0; candidate < profiles.length; candidate++)
          if (candidate !== component)
            other += coefficients[candidate] * profiles[candidate][index];
        numerator += profiles[component][index] * (target[index] - other);
        denominator += profiles[component][index] ** 2;
      }
      coefficients[component] = Math.max(0, numerator / (denominator || 1));
    }
  }
  const coefficientTotal =
    coefficients.reduce((sum, value) => sum + value, 0) || 1;
  const contributions = coefficients.map((value) => value / coefficientTotal);
  const phases: PhaseEvidence[] = selectedResults
    .map((result, index) => {
      const matchedPeakCount = result.matchedPeaks.length;
      const contributionIndex = contributions[index];
      const evidence: PhaseEvidence['evidence'] =
        contributionIndex >= 0.14 &&
        result.expectedCoverage >= 0.58 &&
        matchedPeakCount >= 2
          ? '较强'
          : contributionIndex >= 0.045 &&
              result.expectedCoverage >= 0.4 &&
              matchedPeakCount >= 2
            ? '可能'
            : result.expectedCoverage >= 0.28 && matchedPeakCount >= 2
              ? '弱'
              : '未见明显证据';
      return {
        framework: result.framework,
        material: result.material,
        evidence,
        score: result.score,
        expectedCoverage: result.expectedCoverage,
        matchedPeakCount,
        contributionIndex,
        shift: result.shift,
        reference: result.reference,
      };
    })
    .sort(
      (left, right) =>
        right.contributionIndex - left.contributionIndex ||
        right.expectedCoverage - left.expectedCoverage ||
        right.score - left.score,
    );

  const start = Math.max(5, sample[0].x);
  const end = Math.min(45, sample[sample.length - 1].x);
  const step = 0.04;
  const sampleValues = preprocess(sampleOnGrid(sample, start, end, step), step);
  const samplePeaks = detectPeaks(start, step, sampleValues, 0.045, 0.18);
  const maximum = Math.max(...samplePeaks.map((peak) => peak.y), 1);
  const referencePeaks = new Map<string, Array<{ x: number; y: number }>>();
  for (const phase of phases) {
    const points = referencePoints(phase.reference.pattern);
    const values = preprocess(
      sampleOnGrid(points, start, end, step, phase.shift),
      step,
    );
    referencePeaks.set(
      phase.framework,
      detectPeaks(start, step, values, 0.045, 0.18),
    );
  }
  const peakAssignments = samplePeaks
    .sort((left, right) => right.y - left.y)
    .slice(0, 40)
    .map((peak) => {
      const assignments = phases
        .flatMap((phase) => {
          const candidates = (referencePeaks.get(phase.framework) || []).filter(
            (candidate) => Math.abs(candidate.x - peak.x) <= 0.22,
          );
          if (!candidates.length) return [];
          const nearest = candidates.reduce((best, current) =>
            Math.abs(current.x - peak.x) < Math.abs(best.x - peak.x)
              ? current
              : best,
          );
          return [
            {
              framework: phase.framework,
              referencePeak: nearest.x,
              delta: peak.x - nearest.x,
            },
          ];
        })
        .sort((left, right) => Math.abs(left.delta) - Math.abs(right.delta));
      return {
        position: peak.x,
        relativeIntensity: (100 * peak.y) / maximum,
        assignments,
      };
    });
  return {
    phases,
    peakAssignments,
    amorphous: estimateAmorphousSignal(sample),
  };
}

export function materializePattern(pattern: CompactPattern): Point[] {
  return referencePoints(pattern);
}

export function normalizedForPlot(
  points: Point[],
  start = 5,
  end = 45,
): Point[] {
  const selected = points.filter((point) => point.x >= start && point.x <= end);
  const maximum = Math.max(...selected.map((point) => point.y), 1);
  const stride = Math.max(1, Math.floor(selected.length / 1200));
  return selected
    .filter((_, index) => index % stride === 0)
    .map((point) => ({ x: point.x, y: (100 * point.y) / maximum }));
}
