import fs from 'node:fs/promises';
import {
  analyzeMultiPhase,
  calculateRelativeCrystallinity,
  materializePattern,
  parseIntegrationWindows,
  suggestIntegrationWindows,
} from '../lib/xrd.ts';

const library = JSON.parse(
  await fs.readFile(
    new URL('../public/library/reference-index.json', import.meta.url),
    'utf8',
  ),
);

const interpolate = (points, x) => {
  if (x < points[0].x || x > points.at(-1).x) return 0;
  let low = 0;
  let high = points.length - 1;
  while (high - low > 1) {
    const middle = (low + high) >> 1;
    if (points[middle].x <= x) low = middle;
    else high = middle;
  }
  const left = points[low];
  const right = points[high];
  return left.y + ((right.y - left.y) * (x - left.x)) / (right.x - left.x);
};

const imf = library.references.find(
  (reference) => reference.framework === 'IMF',
);
const mfi = library.references.find(
  (reference) => reference.framework === 'MFI',
);
const quartz = library.references.find(
  (reference) => reference.framework === 'alpha-quartz',
);
if (!imf || !mfi || !quartz)
  throw new Error('Required IMF/MFI/quartz references are missing');

const reference = materializePattern(imf.pattern);
const scaledSample = reference.map((point) => ({
  x: point.x,
  y: point.y * 0.63,
}));
const windows = suggestIntegrationWindows(scaledSample, reference, 6);
const crystallinity = calculateRelativeCrystallinity(
  scaledSample,
  reference,
  windows,
);
if (Math.abs(crystallinity.relativeCrystallinity - 63) > 0.05)
  throw new Error(
    `Expected 63% relative crystallinity, got ${crystallinity.relativeCrystallinity}`,
  );
if (parseIntegrationWindows('7.5-9.0, 22.5–25.0').length !== 2)
  throw new Error('Manual window parser failed');

const componentPatterns = [imf, mfi, quartz].map((record) =>
  materializePattern(record.pattern),
);
const mixed = Array.from({ length: 1001 }, (_, index) => {
  const x = 5 + index * 0.04;
  const sharp =
    interpolate(componentPatterns[0], x) +
    0.8 * interpolate(componentPatterns[1], x) +
    0.7 * interpolate(componentPatterns[2], x);
  const broad = 12 * Math.exp(-0.5 * ((x - 22.5) / 3.2) ** 2);
  return { x, y: sharp + broad + 2 };
});
const multiphase = analyzeMultiPhase(mixed, library, [
  'IMF',
  'MFI',
  'alpha-quartz',
]);
if (multiphase.phases.length !== 3)
  throw new Error('Expected three requested phase results');
if (multiphase.phases.some((phase) => phase.evidence === '未见明显证据'))
  throw new Error(
    `Synthetic phase missed: ${JSON.stringify(multiphase.phases)}`,
  );
if (!multiphase.peakAssignments.some((peak) => peak.assignments.length > 1))
  throw new Error('Expected at least one overlapping peak assignment');
const pureImf = analyzeMultiPhase(reference, library, [
  'IMF',
  'MFI',
  'alpha-quartz',
]);
if (
  pureImf.phases.find((phase) => phase.framework === 'MFI')?.evidence === '较强'
)
  throw new Error(
    `Pure IMF incorrectly gave MFI strong evidence: ${JSON.stringify(pureImf.phases)}`,
  );

console.log(
  JSON.stringify(
    {
      relativeCrystallinity: crystallinity.relativeCrystallinity,
      integrationWindows: crystallinity.windows.length,
      phases: multiphase.phases.map((phase) => ({
        framework: phase.framework,
        evidence: phase.evidence,
        coverage: phase.expectedCoverage,
      })),
      assignedPeaks: multiphase.peakAssignments.filter(
        (peak) => peak.assignments.length,
      ).length,
      amorphousHint: multiphase.amorphous,
      pureImfCheck: pureImf.phases.map((phase) => ({
        framework: phase.framework,
        evidence: phase.evidence,
        contribution: phase.contributionIndex,
      })),
    },
    null,
    2,
  ),
);
