#!/usr/bin/env python3
"""Create the compact browser-side XRD/CIF library from the audited local cache."""

from __future__ import annotations

import json
import math
import re
import shutil
from pathlib import Path


SITE_ROOT = Path(__file__).resolve().parents[1]
WORKSPACE = SITE_ROOT.parent
SOURCE_ROOT = WORKSPACE / "output" / "xrd_reference_library"
OUTPUT_ROOT = SITE_ROOT / "public" / "library"
TARGET_STEP = 0.04


def read_xy(path: Path):
    points = []
    for raw in path.read_text(encoding="utf-8-sig", errors="replace").splitlines():
        line = raw.strip()
        if not line or line.startswith(("#", ";", "!")):
            continue
        fields = re.split(r"[\s,;]+", line)
        if len(fields) < 2:
            continue
        try:
            x, y = float(fields[0]), float(fields[1])
        except ValueError:
            continue
        if math.isfinite(x) and math.isfinite(y):
            points.append((x, y))
    points.sort()
    return points


def interpolate(points, q):
    if q <= points[0][0]:
        return points[0][1]
    if q >= points[-1][0]:
        return points[-1][1]
    lo, hi = 0, len(points) - 1
    while hi - lo > 1:
        mid = (lo + hi) // 2
        if points[mid][0] <= q:
            lo = mid
        else:
            hi = mid
    x0, y0 = points[lo]
    x1, y1 = points[hi]
    return y0 + (y1 - y0) * (q - x0) / (x1 - x0)


def compact_pattern(path: Path):
    points = read_xy(path)
    start = math.ceil(points[0][0] / TARGET_STEP) * TARGET_STEP
    end = math.floor(points[-1][0] / TARGET_STEP) * TARGET_STEP
    count = int(round((end - start) / TARGET_STEP)) + 1
    x = [round(start + i * TARGET_STEP, 4) for i in range(count)]
    y = [round(interpolate(points, q), 4) for q in x]
    maximum = max(y) or 1
    return {"start": x[0], "step": TARGET_STEP, "y": [round(v * 100 / maximum, 3) for v in y]}


def copy_cif(source: Path, name: str):
    target = OUTPUT_ROOT / "cif" / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)
    return f"library/cif/{name}"


def main():
    manifest = json.loads((SOURCE_ROOT / "local_manifest.json").read_text(encoding="utf-8"))
    catalog = json.loads((SOURCE_ROOT / "iza_local_cache" / "structure_catalog.json").read_text(encoding="utf-8"))
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)

    references = []
    for ref in manifest["references"]:
        path = SOURCE_ROOT / ref["path"]
        record = {
            key: ref.get(key)
            for key in (
                "id", "framework", "material", "kind", "state", "source",
                "wavelength_angstrom", "source_wavelength_angstrom", "polymorph_ratio",
            )
            if ref.get(key) is not None
        }
        record["pattern"] = compact_pattern(path)
        references.append(record)

    structures = {}
    for structure in catalog["structures"]:
        framework = structure["framework"]
        if framework == "Beta intergrowth family":
            options = []
            for item in structure["polymorph_cifs"]:
                source = SOURCE_ROOT / item["path"]
                options.append({"label": item["polymorph"], "path": copy_cif(source, f'{item["polymorph"]}.cif')})
            structures["Beta_intergrowth"] = options
            continue
        ideal = structure.get("idealized_framework_cif")
        if ideal:
            source = SOURCE_ROOT / ideal["path"]
            structures[framework] = [{"label": f"{framework} 理想骨架", "path": copy_cif(source, f"{framework}.cif")}]

    quartz_cif = SOURCE_ROOT / "alpha_quartz_COD_9005017" / "alpha_quartz_COD_9005017_298K.cif"
    structures["alpha-quartz"] = [{"label": "α-石英", "path": copy_cif(quartz_cif, "alpha-quartz.cif")}]

    payload = {
        "version": 1,
        "comparison_wavelength_angstrom": 1.5406,
        "reference_count": len(references),
        "framework_count": len(structures),
        "references": references,
        "structures": structures,
        "notes": [
            "Scores rank evidence and are not probabilities or phase fractions.",
            "Relative crystallinity requires a matched physical reference measured under equivalent conditions.",
        ],
    }
    (OUTPUT_ROOT / "reference-index.json").write_text(
        json.dumps(payload, ensure_ascii=False, separators=(",", ":")), encoding="utf-8"
    )
    demo_source = SOURCE_ROOT / "iza_local_cache" / "IMF" / "patterns" / "IMF_IM-5_26_normalized.xy"
    shutil.copy2(demo_source, OUTPUT_ROOT / "demo-im5.xy")
    print(f"Wrote {len(references)} references and {len(structures)} structure groups")


if __name__ == "__main__":
    main()
