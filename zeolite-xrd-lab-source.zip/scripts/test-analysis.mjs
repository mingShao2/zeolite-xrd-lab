import fs from 'node:fs/promises';
import { analyzePattern, parseXrdText } from '../lib/xrd.ts';

const library = JSON.parse(await fs.readFile(new URL('../public/library/reference-index.json', import.meta.url), 'utf8'));
const sample = parseXrdText(await fs.readFile(new URL('../public/library/demo-im5.xy', import.meta.url), 'utf8'));
const results = analyzePattern(sample, library);

if (results[0]?.framework !== 'IMF') throw new Error(`Expected IMF first, got ${results[0]?.framework}`);
if (results[0].score < 99) throw new Error(`Expected near-perfect self-match, got ${results[0].score}`);
console.log(JSON.stringify({ top: results[0].framework, score: results[0].score, candidates: results.slice(0, 5).map((item) => item.framework) }, null, 2));
