from __future__ import annotations

import base64
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
DOCS = ROOT / "docs"
OUTPUT = ROOT / "github-upload"


def main() -> None:
    css_file = next((DOCS / "assets").glob("*.css"))
    js_file = next((DOCS / "assets").glob("*.js"))
    css = css_file.read_text(encoding="utf-8").replace("</style", "<\\/style")
    javascript = js_file.read_text(encoding="utf-8").replace("</script", "<\\/script")

    embedded: dict[str, dict[str, str]] = {}
    for path in sorted((DOCS / "library").rglob("*")):
        if not path.is_file():
            continue
        key = path.relative_to(DOCS).as_posix()
        mime = "application/json" if path.suffix == ".json" else "text/plain; charset=utf-8"
        embedded[key] = {
            "mime": mime,
            "base64": base64.b64encode(path.read_bytes()).decode("ascii"),
        }

    data = json.dumps(embedded, ensure_ascii=True, separators=(",", ":"))
    fetch_shim = f"""
const __xrdAssets={data};
const __nativeFetch=window.fetch.bind(window);
window.fetch=(input,init)=>{{
  const url=new URL(input instanceof Request?input.url:String(input),document.baseURI);
  const marker='/library/';
  const at=url.pathname.indexOf(marker);
  if(at>=0){{
    const key='library/'+url.pathname.slice(at+marker.length);
    const asset=__xrdAssets[key];
    if(asset){{
      const binary=atob(asset.base64);
      const bytes=Uint8Array.from(binary,c=>c.charCodeAt(0));
      return Promise.resolve(new Response(bytes,{{status:200,headers:{{'Content-Type':asset.mime}}}}));
    }}
  }}
  return __nativeFetch(input,init);
}};
"""

    html = f"""<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="浏览器端分子筛粉末 XRD 结构匹配与 CIF 骨架可视化工具">
  <title>Zeolite XRD Lab</title>
  <style>{css}</style>
</head>
<body>
  <div id="root"></div>
  <script>{fetch_shim}</script>
  <script type="module">{javascript}</script>
</body>
</html>
"""

    OUTPUT.mkdir(exist_ok=True)
    (OUTPUT / "index.html").write_text(html, encoding="utf-8")
    (OUTPUT / "README.md").write_text((ROOT / "README.md").read_text(encoding="utf-8"), encoding="utf-8")
    print(f"Wrote {OUTPUT / 'index.html'} ({len(html.encode('utf-8')):,} bytes; {len(embedded)} embedded assets)")


if __name__ == "__main__":
    main()
