'use client';

import { useState } from 'react';
import { AlertTriangle, Download, Layers3, Play } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  analyzeMultiPhase,
  type MultiPhaseResult,
  type Point,
  type ReferenceLibrary,
} from '@/lib/xrd';

function downloadAssignments(result: MultiPhaseResult) {
  const header = [
    '# Zeolite XRD Lab multi-phase peak assignments',
    '# assignments are candidate explanations, not quantitative phase fractions',
    `# amorphous_broad_hump_hint: ${result.amorphous.level}`,
    `# broad_signal_index_nonquantitative: ${result.amorphous.broadSignalIndex.toFixed(4)}`,
    '# columns: sample_2theta_deg relative_intensity candidate_phases reference_peaks_deg delta_deg',
  ];
  const rows = result.peakAssignments.map((peak) =>
    [
      peak.position.toFixed(4),
      peak.relativeIntensity.toFixed(3),
      peak.assignments.map((item) => item.framework).join('|') || 'unexplained',
      peak.assignments.map((item) => item.referencePeak.toFixed(4)).join('|'),
      peak.assignments.map((item) => item.delta.toFixed(4)).join('|'),
    ].join('\t'),
  );
  const url = URL.createObjectURL(
    new Blob([[...header, ...rows].join('\r\n') + '\r\n'], {
      type: 'text/plain;charset=utf-8',
    }),
  );
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = 'xrd_multiphase_peak_assignments.txt';
  anchor.click();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}

const evidenceVariant = (evidence: string) =>
  evidence === '较强'
    ? ('default' as const)
    : evidence === '可能'
      ? ('secondary' as const)
      : ('outline' as const);

export function MultiPhasePanel({
  sample,
  library,
}: {
  sample: Point[];
  library: ReferenceLibrary | null;
}) {
  const [phaseText, setPhaseText] = useState('IMF, MFI, alpha-quartz');
  const [result, setResult] = useState<MultiPhaseResult | null>(null);
  const [resultSignature, setResultSignature] = useState('');
  const [error, setError] = useState('');
  const sampleSignature = sample.length
    ? `${sample.length}:${sample[0].x.toFixed(4)}:${sample[sample.length - 1].x.toFixed(4)}:${sample[Math.floor(sample.length / 2)].y.toFixed(4)}`
    : '';
  const currentResult = resultSignature === sampleSignature ? result : null;

  function run() {
    try {
      if (!library || !sample.length)
        throw new Error('请先上传并完成实验谱分析。');
      const requested = phaseText
        .split(/[,，;；\n]+/)
        .map((item) => item.trim())
        .filter(Boolean);
      setResult(analyzeMultiPhase(sample, library, requested));
      setResultSignature(sampleSignature);
      setError('');
    } catch (reason) {
      setResult(null);
      setError(reason instanceof Error ? reason.message : String(reason));
    }
  }

  return (
    <Card className="border-0 shadow-[0_10px_40px_rgba(16,42,67,.08)]">
      <CardHeader className="border-b border-border/70">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <CardTitle className="flex items-center gap-2">
            <Layers3 className="size-4 text-primary" /> 多物相识别与实验峰归属
          </CardTitle>
          {currentResult && (
            <Button
              size="sm"
              variant="outline"
              onClick={() => downloadAssignments(currentResult)}
            >
              <Download /> 下载归属表
            </Button>
          )}
        </div>
      </CardHeader>
      <CardContent className="space-y-5 pt-5">
        <div className="grid gap-3 lg:grid-cols-[minmax(0,1fr)_auto] lg:items-end">
          <div className="space-y-2">
            <Label htmlFor="phase-list">要同时核对的物相</Label>
            <Input
              id="phase-list"
              value={phaseText}
              onChange={(event) => setPhaseText(event.target.value)}
              placeholder="IMF, MFI, alpha-quartz"
            />
            <p className="text-xs text-muted-foreground">
              输入 IZA 框架代码，石英可写 alpha-quartz
              或“石英”。无定形相由宽弥散峰单独提示。
            </p>
          </div>
          <Button disabled={!library || !sample.length} onClick={run}>
            <Play /> 运行多物相核对
          </Button>
        </div>
        {error && (
          <div className="flex gap-2 rounded-lg bg-red-50 p-3 text-sm text-red-800">
            <AlertTriangle className="mt-0.5 size-4 shrink-0" />
            {error}
          </div>
        )}
        {currentResult && (
          <div className="grid gap-5 xl:grid-cols-[minmax(0,.82fr)_minmax(0,1.18fr)]">
            <div className="space-y-3">
              <div className="space-y-2">
                {currentResult.phases.map((phase) => (
                  <div
                    key={phase.framework}
                    className="rounded-xl border bg-card p-3"
                  >
                    <div className="flex items-center justify-between gap-3">
                      <div>
                        <b className="text-lg text-primary">
                          {phase.framework}
                        </b>
                        <div className="mt-0.5 text-xs text-muted-foreground">
                          {phase.material}
                        </div>
                      </div>
                      <Badge variant={evidenceVariant(phase.evidence)}>
                        {phase.evidence}
                      </Badge>
                    </div>
                    <div className="mt-3 grid grid-cols-4 gap-2 text-xs">
                      <span>
                        <i className="block not-italic text-muted-foreground">
                          联合贡献
                        </i>
                        <b>{(phase.contributionIndex * 100).toFixed(0)}</b>
                      </span>
                      <span>
                        <i className="block not-italic text-muted-foreground">
                          预期峰覆盖
                        </i>
                        <b>{(phase.expectedCoverage * 100).toFixed(0)}%</b>
                      </span>
                      <span>
                        <i className="block not-italic text-muted-foreground">
                          匹配峰
                        </i>
                        <b>{phase.matchedPeakCount}</b>
                      </span>
                      <span>
                        <i className="block not-italic text-muted-foreground">
                          校正
                        </i>
                        <b>
                          {phase.shift >= 0 ? '+' : ''}
                          {phase.shift.toFixed(2)}°
                        </b>
                      </span>
                    </div>
                  </div>
                ))}
              </div>
              <div className="rounded-xl border border-amber-300 bg-amber-50 p-4 text-sm leading-6 text-amber-950">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <b>无定形宽峰：{currentResult.amorphous.level}</b>
                  <span className="text-xs">
                    非定量指标{' '}
                    {(currentResult.amorphous.broadSignalIndex * 100).toFixed(
                      0,
                    )}
                  </span>
                </div>
                {currentResult.amorphous.center !== null && (
                  <div className="mt-1">
                    宽背景中心约 {currentResult.amorphous.center.toFixed(1)}° 2θ
                  </div>
                )}
                <div className="mt-2 text-xs leading-5 text-amber-800">
                  {currentResult.amorphous.note}
                </div>
              </div>
              <p className="text-xs leading-5 text-muted-foreground">
                “联合贡献”表示该参考谱在多候选非负联合拟合中的相对解释能力，不是质量分数。若需定量相分析/绝对无定形含量，需要内标和经校准的全谱拟合。
              </p>
            </div>
            <div className="min-w-0">
              <div className="mb-2 flex items-center justify-between text-sm">
                <b>实验峰可能归属</b>
                <span className="text-xs text-muted-foreground">
                  容差 ±0.22° 2θ
                </span>
              </div>
              <div className="max-h-[470px] overflow-auto rounded-xl border">
                <table className="w-full text-xs">
                  <thead className="sticky top-0 bg-muted">
                    <tr>
                      <th className="p-2 text-left">实验 2θ</th>
                      <th className="p-2 text-right">相对强度</th>
                      <th className="p-2 text-left">候选物相</th>
                      <th className="p-2 text-left">参考峰 / 偏差</th>
                    </tr>
                  </thead>
                  <tbody>
                    {currentResult.peakAssignments.map((peak) => (
                      <tr key={peak.position} className="border-t align-top">
                        <td className="p-2 font-medium tabular-nums">
                          {peak.position.toFixed(2)}°
                        </td>
                        <td className="p-2 text-right tabular-nums">
                          {peak.relativeIntensity.toFixed(0)}%
                        </td>
                        <td className="p-2">
                          {peak.assignments.length ? (
                            <div className="flex flex-wrap gap-1">
                              {peak.assignments.map((assignment) => (
                                <Badge
                                  key={assignment.framework}
                                  variant="outline"
                                >
                                  {assignment.framework}
                                </Badge>
                              ))}
                            </div>
                          ) : (
                            <span className="text-red-700">未解释</span>
                          )}
                        </td>
                        <td className="p-2 text-muted-foreground">
                          {peak.assignments
                            .map(
                              (assignment) =>
                                `${assignment.referencePeak.toFixed(2)}° (${assignment.delta >= 0 ? '+' : ''}${assignment.delta.toFixed(2)}°)`,
                            )
                            .join(' · ') || '—'}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}
        {!currentResult && !error && (
          <div className="grid min-h-36 place-items-center rounded-xl border border-dashed text-center text-muted-foreground">
            <div>
              <Layers3 className="mx-auto mb-2 size-7" />
              <p>可同时核对 IMF、MFI、α-石英等，并列出每个实验峰的可能归属</p>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
