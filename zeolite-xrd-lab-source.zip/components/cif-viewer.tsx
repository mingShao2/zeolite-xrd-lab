'use client';

import { useEffect, useMemo, useRef, useState } from 'react';
import { Atom, Rotate3D } from 'lucide-react';

type AtomPoint = { element: string; x: number; y: number; z: number };
type Bond = [number, number];

function tokenize(line: string) {
  return line.match(/'(?:[^']*)'|"(?:[^"]*)"|\S+/g)?.map((v) => v.replace(/^['"]|['"]$/g, '')) || [];
}

function coordinateExpression(expression: string, point: { x: number; y: number; z: number }) {
  const parts = expression.replace(/\s/g, '').replace(/-/g, '+-').split('+').filter(Boolean);
  let value = 0;
  for (const part of parts) {
    if (/^-?x$/i.test(part)) value += part.startsWith('-') ? -point.x : point.x;
    else if (/^-?y$/i.test(part)) value += part.startsWith('-') ? -point.y : point.y;
    else if (/^-?z$/i.test(part)) value += part.startsWith('-') ? -point.z : point.z;
    else if (/^-?\d+\/\d+$/.test(part)) { const [top, bottom] = part.split('/').map(Number); value += top / bottom; }
    else if (Number.isFinite(Number(part))) value += Number(part);
  }
  return ((value % 1) + 1) % 1;
}

function parseCif(text: string) {
  const scalar = (name: string, fallback: number) => {
    const match = text.match(new RegExp(`^${name}\\s+([^\\s#]+)`, 'mi'));
    const value = match ? Number(match[1].replace(/\(.*/, '')) : fallback;
    return Number.isFinite(value) ? value : fallback;
  };
  const a = scalar('_cell_length_a', 20), b = scalar('_cell_length_b', a), c = scalar('_cell_length_c', a);
  const alpha = scalar('_cell_angle_alpha', 90) * Math.PI / 180;
  const beta = scalar('_cell_angle_beta', 90) * Math.PI / 180;
  const gamma = scalar('_cell_angle_gamma', 90) * Math.PI / 180;
  const lines = text.split(/\r?\n/);
  const symmetry: string[] = [];
  for (let i = 0; i < lines.length; i++) {
    if (!/^_(symmetry_equiv_pos_as_xyz|space_group_symop_operation_xyz)/i.test(lines[i].trim())) continue;
    let j = i + 1;
    while (j < lines.length) {
      const line = lines[j].trim();
      if (!line || line.startsWith('#')) { j++; continue; }
      if (line.startsWith('_') || line.toLowerCase() === 'loop_' || line.toLowerCase().startsWith('data_')) break;
      const operation = tokenize(line)[0];
      if (operation?.includes(',')) symmetry.push(operation);
      j++;
    }
  }
  if (!symmetry.length) symmetry.push('x,y,z');
  const sites: Array<{ element: string; x: number; y: number; z: number }> = [];
  for (let i = 0; i < lines.length; i++) {
    if (lines[i].trim().toLowerCase() !== 'loop_') continue;
    const headers: string[] = [];
    let j = i + 1;
    while (j < lines.length && lines[j].trim().startsWith('_')) { headers.push(lines[j].trim().split(/\s+/)[0].toLowerCase()); j++; }
    const ix = headers.indexOf('_atom_site_fract_x');
    const iy = headers.indexOf('_atom_site_fract_y');
    const iz = headers.indexOf('_atom_site_fract_z');
    const ie = headers.findIndex((header) => header === '_atom_site_type_symbol');
    const il = headers.findIndex((header) => header === '_atom_site_label');
    if (ix < 0 || iy < 0 || iz < 0) continue;
    while (j < lines.length) {
      const line = lines[j].trim();
      if (!line || line.startsWith('#')) { j++; continue; }
      if (line.startsWith('_') || line.toLowerCase() === 'loop_' || line.toLowerCase().startsWith('data_')) break;
      const values = tokenize(line);
      if (values.length < headers.length) break;
      const clean = (value: string) => Number(value.replace(/\(.*/, ''));
      const fx = clean(values[ix]), fy = clean(values[iy]), fz = clean(values[iz]);
      if ([fx, fy, fz].every(Number.isFinite)) {
        const rawElement = values[ie >= 0 ? ie : il] || 'T';
        const element = (rawElement.match(/[A-Za-z]+/)?.[0] || 'T').replace(/^./, (m) => m.toUpperCase()).replace(/(.)(.*)/, (_, x, rest) => x + rest.toLowerCase());
        sites.push({ element, x: fx, y: fy, z: fz });
      }
      j++;
    }
    if (sites.length) break;
  }
  const expanded: typeof sites = [];
  const seen = new Set<string>();
  for (const site of sites) for (const operation of symmetry) {
    const expressions = operation.split(',');
    if (expressions.length !== 3) continue;
    const atom = { element: site.element, x: coordinateExpression(expressions[0], site), y: coordinateExpression(expressions[1], site), z: coordinateExpression(expressions[2], site) };
    const key = `${atom.element}:${atom.x.toFixed(4)}:${atom.y.toFixed(4)}:${atom.z.toFixed(4)}`;
    if (!seen.has(key)) { seen.add(key); expanded.push(atom); }
  }
  const selectedSites = expanded.length <= 1800 ? expanded : expanded.filter((_, index) => index % Math.ceil(expanded.length / 1800) === 0);
  const zComponent = (Math.cos(alpha) - Math.cos(beta) * Math.cos(gamma)) / Math.sin(gamma);
  const zFactor = Math.sqrt(Math.max(0, 1 - Math.cos(beta) ** 2 - zComponent ** 2));
  const limited: AtomPoint[] = selectedSites.map((site) => ({
    element: site.element,
    x: a * site.x + b * Math.cos(gamma) * site.y + c * Math.cos(beta) * site.z,
    y: b * Math.sin(gamma) * site.y + c * zComponent * site.z,
    z: c * zFactor * site.z,
  }));
  const bonds: Bond[] = [];
  const oxygen = limited.map((atom, index) => ({ atom, index })).filter(({ atom }) => atom.element === 'O');
  const tetrahedral = limited.map((atom, index) => ({ atom, index })).filter(({ atom }) => atom.element !== 'O');
  for (const left of oxygen) for (const right of tetrahedral) {
    const i = left.index, j = right.index;
    const d = Math.hypot(limited[i].x - limited[j].x, limited[i].y - limited[j].y, limited[i].z - limited[j].z);
    if (d > 1.15 && d < 2.15) bonds.push([i, j]);
  }
  return { atoms: limited, bonds };
}

const colors: Record<string, string> = { O: '#45c7e5', Si: '#f6c85f', Al: '#d988e7', P: '#ff8a65', Ge: '#9bd16f', B: '#ef7c9c' };

export function CifViewer({ path, label }: { path?: string; label?: string }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [model, setModel] = useState<{ atoms: AtomPoint[]; bonds: Bond[] }>({ atoms: [], bonds: [] });
  const [angle, setAngle] = useState({ x: -0.45, y: 0.65 });
  const drag = useRef<{ x: number; y: number; ax: number; ay: number } | null>(null);

  useEffect(() => {
    if (!path) { setModel({ atoms: [], bonds: [] }); return; }
    fetch(path).then((r) => r.text()).then(parseCif).then(setModel).catch(() => setModel({ atoms: [], bonds: [] }));
  }, [path]);

  const centered = useMemo(() => {
    if (!model.atoms.length) return [];
    const center = model.atoms.reduce((sum, atom) => ({ x: sum.x + atom.x, y: sum.y + atom.y, z: sum.z + atom.z }), { x: 0, y: 0, z: 0 });
    center.x /= model.atoms.length; center.y /= model.atoms.length; center.z /= model.atoms.length;
    return model.atoms.map((atom) => ({ ...atom, x: atom.x - center.x, y: atom.y - center.y, z: atom.z - center.z }));
  }, [model]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || !centered.length) return;
    const context = canvas.getContext('2d');
    if (!context) return;
    const ratio = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    canvas.width = rect.width * ratio; canvas.height = rect.height * ratio;
    context.scale(ratio, ratio); context.clearRect(0, 0, rect.width, rect.height);
    const rotate = (atom: AtomPoint) => {
      const cy = Math.cos(angle.y), sy = Math.sin(angle.y), cx = Math.cos(angle.x), sx = Math.sin(angle.x);
      const x1 = atom.x * cy + atom.z * sy, z1 = -atom.x * sy + atom.z * cy;
      return { ...atom, x: x1, y: atom.y * cx - z1 * sx, z: atom.y * sx + z1 * cx };
    };
    const rotated = centered.map(rotate);
    const extent = Math.max(...rotated.flatMap((p) => [Math.abs(p.x), Math.abs(p.y)]), 1);
    const scale = Math.min(rect.width, rect.height) * 0.39 / extent;
    const projected = rotated.map((p) => ({ ...p, px: rect.width / 2 + p.x * scale, py: rect.height / 2 + p.y * scale }));
    context.lineWidth = 1;
    for (const [i, j] of model.bonds) {
      context.strokeStyle = 'rgba(126,165,190,.36)'; context.beginPath(); context.moveTo(projected[i].px, projected[i].py); context.lineTo(projected[j].px, projected[j].py); context.stroke();
    }
    projected.map((atom, index) => ({ atom, index })).sort((a, b) => a.atom.z - b.atom.z).forEach(({ atom }) => {
      const radius = atom.element === 'O' ? 2.2 : 3.8;
      context.fillStyle = colors[atom.element] || '#a8b8c8'; context.beginPath(); context.arc(atom.px, atom.py, radius, 0, Math.PI * 2); context.fill();
    });
  }, [centered, model.bonds, angle]);

  if (!path) return <div className="grid h-64 place-items-center rounded-xl bg-muted/60 text-center text-muted-foreground"><div><Atom className="mx-auto mb-3 size-8" /><p>选择候选结构后查看 CIF 骨架</p></div></div>;

  return (
    <div className="relative h-64 overflow-hidden rounded-xl bg-[#071525]">
      <canvas ref={canvasRef} className="h-full w-full cursor-grab touch-none active:cursor-grabbing" onPointerDown={(event) => { event.currentTarget.setPointerCapture(event.pointerId); drag.current = { x: event.clientX, y: event.clientY, ax: angle.x, ay: angle.y }; }} onPointerMove={(event) => { if (!drag.current) return; setAngle({ x: drag.current.ax + (event.clientY - drag.current.y) * 0.008, y: drag.current.ay + (event.clientX - drag.current.x) * 0.008 }); }} onPointerUp={() => { drag.current = null; }} />
      <div className="pointer-events-none absolute inset-x-3 top-3 flex items-center justify-between"><span className="rounded-md bg-black/35 px-2 py-1 text-xs text-white/85">{label}</span><span className="flex items-center gap-1 text-xs text-white/55"><Rotate3D className="size-3" /> 拖动旋转</span></div>
      <div className="pointer-events-none absolute bottom-3 left-3 flex gap-3 text-[11px] text-white/65"><span><i className="mr-1 inline-block size-2 rounded-full bg-[#f6c85f]" />Si/T</span><span><i className="mr-1 inline-block size-2 rounded-full bg-[#45c7e5]" />O</span></div>
    </div>
  );
}
