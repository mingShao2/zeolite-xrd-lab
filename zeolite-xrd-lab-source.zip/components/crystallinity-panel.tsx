'use client';

import { useMemo, useState } from 'react';
import {
  AlertTriangle,
  Calculator,
  CheckCircle2,
  Download,
  FileUp,
  WandSparkles,
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  calculateRelativeCrystallinity,
  parseIntegrationWindows,
  parseXrdText,
  suggestIntegrationWindows,
  type Point,
  type RelativeCrystallinityResult,
} from '@/lib/xrd';

function downloadCalculation(
  result: RelativeCrystallinityResult,
  sampleName: string,
  referenceName: string,
) {
  const header = [
    '# Zeolite XRD Lab relative crystallinity calculation',
    `# sample: ${sampleName || 'sample'}`,
    `# physical_reference: ${referenceName || 'physical reference'}`,
    '# formula: RC(%) = 100 * sum(sample net peak area) / sum(reference net peak area)',
    `# sample_area_sum: ${result.sampleArea.toFixed(8)}`,
    `# reference_area_sum: ${result.referenceArea.toFixed(8)}`,
    `# relative_crystallinity_percent: ${result.relativeCrystallinity.toFixed(4)}`,
    '# baseline: straight line between the two endpoints of each window; negative net intensity clipped to zero',
    '# columns: window_label start_deg end_deg sample_net_area reference_net_area window_ratio_percent',
  ];
  const rows = result.windows.map((window) =>
    [
      window.label || '',
      window.start.toFixed(4),
      window.end.toFixed(4),
      window.sampleArea.toFixed(8),
      window.referenceArea.toFixed(8),
      window.ratioPercent.toFixed(4),
    ].join('\t'),
  );
  const url = URL.createObjectURL(
    new Blob([[...header, ...rows].join('\r\n') + '\r\n'], {
      type: 'text/plain;charset=utf-8',
    }),
  );
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = `${(sampleName || 'sample').replace(/[^\p{L}\p{N}._-]+/gu, '_')}_relative_crystallinity.txt`;
  anchor.click();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export function CrystallinityPanel({
  sample,
  sampleName,
}: {
  sample: Point[];
  sampleName: string;
}) {
  const [reference, setReference] = useState<Point[]>([]);
  const [referenceFile, setReferenceFile] = useState('');
  const [referenceName, setReferenceName] = useState('');
  const [referenceBatch, setReferenceBatch] = useState('');
  const [mode, setMode] = useState('manual');
  const [windowText, setWindowText] = useState('7.5-9.0, 13.0-14.2, 22.5-25.0');
  const [conditionsConfirmed, setConditionsConfirmed] = useState(false);
  const [result, setResult] = useState<RelativeCrystallinityResult | null>(
    null,
  );
  const [error, setError] = useState('');

  const commonRange = useMemo(() => {
    if (!sample.length || !reference.length) return '';
    return `${Math.max(sample[0].x, reference[0].x).toFixed(2)}–${Math.min(sample[sample.length - 1].x, reference[reference.length - 1].x).toFixed(2)}°`;
  }, [sample, reference]);

  async function handleReference(file?: File) {
    if (!file) return;
    try {
      const points = parseXrdText(await file.text());
      setReference(points);
      setReferenceFile(file.name);
      setReferenceName(
        (current) => current || file.name.replace(/\.[^.]+$/, ''),
      );
      setResult(null);
      setError('');
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : String(reason));
    }
  }

  function chooseCharacteristicPeaks() {
    try {
      const windows = suggestIntegrationWindows(sample, reference);
      setWindowText(
        windows
          .map(
            (window) => `${window.start.toFixed(2)}-${window.end.toFixed(2)}`,
          )
          .join(', '),
      );
      setError('');
      setResult(null);
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : String(reason));
    }
  }

  function calculate() {
    try {
      if (!conditionsConfirmed)
        throw new Error(
          '请先确认实体标样与样品为同一框架，并在等同条件下测量。',
        );
      const windows = parseIntegrationWindows(windowText);
      setResult(calculateRelativeCrystallinity(sample, reference, windows));
      setError('');
    } catch (reason) {
      setResult(null);
      setError(reason instanceof Error ? reason.message : String(reason));
    }
  }

  return (
    <Card className="border-0 shadow-[0_10px_40px_rgba(16,42,67,.08)]">
      <CardHeader className="border-b border-border/70">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <CardTitle className="flex items-center gap-2">
            <Calculator className="size-4 text-primary" />{' '}
            相对结晶度（实体标样）
          </CardTitle>
          <Badge variant="outline">面积比法</Badge>
        </div>
      </CardHeader>
      <CardContent className="grid gap-5 pt-5 xl:grid-cols-[minmax(0,.9fr)_minmax(0,1.1fr)]">
        <div className="space-y-4">
          <label
            aria-label="上传同结构实体标样 XRD 数据"
            className="grid min-h-28 cursor-pointer place-items-center rounded-xl border border-dashed border-primary/35 bg-primary/[.035] p-4 text-center transition hover:bg-primary/[.07]"
          >
            <input
              type="file"
              accept=".txt,.xy,.xye,.csv,.dat"
              className="sr-only"
              onChange={(event) =>
                void handleReference(event.target.files?.[0])
              }
            />
            <span>
              <span className="mx-auto mb-2 grid size-9 place-items-center rounded-full bg-card text-primary shadow-sm">
                {reference.length ? (
                  <CheckCircle2 className="size-5" />
                ) : (
                  <FileUp className="size-5" />
                )}
              </span>
              <span className="block max-w-72 truncate font-medium">
                {referenceFile || '上传同结构实体标样谱'}
              </span>
              <span className="mt-1 block text-xs text-muted-foreground">
                不接受数据库模拟谱作结晶度标样
              </span>
            </span>
          </label>
          <div className="grid gap-3 sm:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="reference-name">标样名称</Label>
              <Input
                id="reference-name"
                value={referenceName}
                onChange={(event) => setReferenceName(event.target.value)}
                placeholder="例如 IMF 标准样"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="reference-batch">批次 / 编号</Label>
              <Input
                id="reference-batch"
                value={referenceBatch}
                onChange={(event) => setReferenceBatch(event.target.value)}
                placeholder="用于追溯"
              />
            </div>
          </div>
          <div className="space-y-2">
            <Label>区间选择</Label>
            <Select
              value={mode}
              onValueChange={(value) => setMode(value || 'manual')}
            >
              <SelectTrigger className="w-full">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="manual">手动积分区间</SelectItem>
                <SelectItem value="peaks">从实体标样自动选特征峰</SelectItem>
              </SelectContent>
            </Select>
          </div>
          {mode === 'peaks' && (
            <Button
              variant="outline"
              className="w-full"
              disabled={!sample.length || !reference.length}
              onClick={chooseCharacteristicPeaks}
            >
              <WandSparkles /> 生成 6 个特征峰窗口
            </Button>
          )}
          <div className="space-y-2">
            <Label htmlFor="integration-windows">积分区间（2θ）</Label>
            <Input
              id="integration-windows"
              value={windowText}
              onChange={(event) => {
                setWindowText(event.target.value);
                setResult(null);
              }}
              placeholder="7.5-9.0, 13.0-14.2, 22.5-25.0"
            />
            <p className="text-xs leading-5 text-muted-foreground">
              使用逗号分隔；每个区间都以两端点直线作背景。
              {commonRange && ` 两谱共同范围：${commonRange}`}
            </p>
          </div>
          <label className="flex cursor-pointer items-start gap-3 rounded-xl border bg-muted/45 p-3 text-sm leading-6">
            <input
              type="checkbox"
              className="mt-1 size-4 accent-blue-600"
              checked={conditionsConfirmed}
              onChange={(event) => setConditionsConfirmed(event.target.checked)}
            />
            <span>
              我确认样品与实体标样为同一框架，且样品制备、水合/焙烧状态、仪器和扫描条件可比。
            </span>
          </label>
          <Button
            className="w-full"
            disabled={!sample.length || !reference.length}
            onClick={calculate}
          >
            <Calculator /> 计算相对结晶度
          </Button>
          {error && (
            <div className="flex gap-2 rounded-lg bg-red-50 p-3 text-sm text-red-800">
              <AlertTriangle className="mt-0.5 size-4 shrink-0" />
              {error}
            </div>
          )}
        </div>

        <div className="min-w-0">
          {result ? (
            <div className="space-y-4">
              <div className="rounded-2xl bg-[#071525] p-5 text-white">
                <div className="text-sm text-slate-300">相对结晶度</div>
                <div className="mt-1 text-4xl font-semibold tabular-nums text-cyan-300">
                  {result.relativeCrystallinity.toFixed(1)}%
                </div>
                <div className="mt-3 text-xs leading-5 text-slate-400">
                  100 × Σ样品净峰面积 {result.sampleArea.toFixed(3)} /
                  Σ标样净峰面积 {result.referenceArea.toFixed(3)}
                </div>
                {referenceBatch && (
                  <div className="mt-1 text-xs text-slate-500">
                    标样批次：{referenceBatch}
                  </div>
                )}
              </div>
              {result.relativeCrystallinity > 100 && (
                <div className="rounded-xl border border-amber-300 bg-amber-50 p-3 text-sm leading-6 text-amber-900">
                  结果超过
                  100%，未做封顶。请核查标样赋值、取向、含水状态、制样量及背景。
                </div>
              )}
              <div className="max-h-72 overflow-auto rounded-xl border">
                <table className="w-full text-xs">
                  <thead className="sticky top-0 bg-muted">
                    <tr>
                      <th className="p-2 text-left">区间</th>
                      <th className="p-2 text-right">样品面积</th>
                      <th className="p-2 text-right">标样面积</th>
                      <th className="p-2 text-right">区间比</th>
                    </tr>
                  </thead>
                  <tbody>
                    {result.windows.map((window) => (
                      <tr
                        key={`${window.start}-${window.end}`}
                        className="border-t"
                      >
                        <td className="p-2">
                          {window.start.toFixed(2)}–{window.end.toFixed(2)}°
                        </td>
                        <td className="p-2 text-right tabular-nums">
                          {window.sampleArea.toFixed(3)}
                        </td>
                        <td className="p-2 text-right tabular-nums">
                          {window.referenceArea.toFixed(3)}
                        </td>
                        <td className="p-2 text-right tabular-nums">
                          {Number.isFinite(window.ratioPercent)
                            ? `${window.ratioPercent.toFixed(1)}%`
                            : '—'}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <Button
                variant="outline"
                onClick={() =>
                  downloadCalculation(result, sampleName, referenceName)
                }
              >
                <Download /> 下载计算依据 TXT
              </Button>
              <p className="text-xs leading-5 text-muted-foreground">
                本结果是相对实体标样的净峰面积比，不是绝对无定形含量或质量分数。用于发布或出厂判定前，应使用实验室验证的固定窗口和平行制样。
              </p>
            </div>
          ) : (
            <div className="grid min-h-80 place-items-center rounded-xl border border-dashed text-center text-muted-foreground">
              <div>
                <Calculator className="mx-auto mb-3 size-8" />
                <p>上传实体标样后输出分区间面积与总面积比</p>
                <p className="mt-1 text-xs">不会用 CIF 模拟谱计算“结晶度”</p>
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
