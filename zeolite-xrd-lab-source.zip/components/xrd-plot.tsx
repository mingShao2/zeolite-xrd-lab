'use client';

import { useMemo } from 'react';
import type { MatchResult, Point } from '@/lib/xrd';

type Props = { sample: Point[]; reference: Point[]; result?: MatchResult; start?: number; end?: number };

export function XrdPlot({ sample, reference, result, start = 5, end = 45 }: Props) {
  const width = 1000;
  const height = 320;
  const pad = { left: 54, right: 18, top: 22, bottom: 40 };
  const px = (x: number) => pad.left + ((x - start) / (end - start)) * (width - pad.left - pad.right);
  const py = (y: number) => pad.top + (1 - y / 100) * (height - pad.top - pad.bottom);
  const samplePath = useMemo(() => sample.map((p, i) => `${i ? 'L' : 'M'}${px(p.x).toFixed(1)},${py(p.y).toFixed(1)}`).join(' '), [sample, start, end]);
  const referencePath = useMemo(() => reference.map((p, i) => `${i ? 'L' : 'M'}${px(p.x).toFixed(1)},${py(p.y).toFixed(1)}`).join(' '), [reference, start, end]);
  const ticks = Array.from({ length: 9 }, (_, i) => start + ((end - start) * i) / 8);

  return (
    <div className="relative h-[330px] overflow-hidden rounded-xl bg-[#071525] p-1">
      <svg viewBox={`0 0 ${width} ${height}`} className="h-full w-full" role="img" aria-label="实验谱与候选参考谱叠加图">
        <defs>
          <linearGradient id="plot-sample" x1="0" x2="1"><stop stopColor="#22d3ee" /><stop offset="1" stopColor="#60a5fa" /></linearGradient>
          <filter id="glow"><feGaussianBlur stdDeviation="1.7" result="b" /><feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge></filter>
        </defs>
        {ticks.map((tick) => <g key={tick}><line x1={px(tick)} x2={px(tick)} y1={pad.top} y2={height - pad.bottom} stroke="#8cb6db" strokeOpacity=".11" /><text x={px(tick)} y={height - 14} textAnchor="middle" fill="#86a3be" fontSize="11">{tick.toFixed(0)}</text></g>)}
        {[0, 25, 50, 75, 100].map((tick) => <g key={tick}><line x1={pad.left} x2={width - pad.right} y1={py(tick)} y2={py(tick)} stroke="#8cb6db" strokeOpacity=".11" /><text x={pad.left - 10} y={py(tick) + 4} textAnchor="end" fill="#86a3be" fontSize="10">{tick}</text></g>)}
        <line x1={pad.left} x2={width - pad.right} y1={height - pad.bottom} y2={height - pad.bottom} stroke="#6f8da9" strokeOpacity=".65" />
        {result?.matchedPeaks.slice(0, 18).map((peak) => <line key={`${peak.expected}-${peak.observed}`} x1={px(peak.observed)} x2={px(peak.observed)} y1={pad.top} y2={height - pad.bottom} stroke="#34d399" strokeOpacity=".24" strokeDasharray="3 5" />)}
        {referencePath && <path d={referencePath} fill="none" stroke="#fbbf24" strokeWidth="1.35" strokeOpacity=".86" />}
        {samplePath && <path d={samplePath} fill="none" stroke="url(#plot-sample)" strokeWidth="1.7" filter="url(#glow)" />}
        <g transform={`translate(${pad.left + 8} ${pad.top + 10})`} fontSize="11"><line x1="0" x2="22" y1="0" y2="0" stroke="#35ccec" strokeWidth="2" /><text x="29" y="4" fill="#c9e9f4">实验谱</text><line x1="90" x2="112" y1="0" y2="0" stroke="#fbbf24" strokeWidth="2" /><text x="119" y="4" fill="#f5dda0">候选参考</text></g>
        <text x={(pad.left + width - pad.right) / 2} y={height - 2} textAnchor="middle" fill="#9bb3c9" fontSize="12">2θ / °</text>
        <text x="13" y={height / 2} textAnchor="middle" fill="#9bb3c9" fontSize="12" transform={`rotate(-90 13 ${height / 2})`}>归一化强度</text>
      </svg>
    </div>
  );
}
